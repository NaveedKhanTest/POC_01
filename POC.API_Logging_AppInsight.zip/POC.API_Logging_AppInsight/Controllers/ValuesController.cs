﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace POC.API_Logging_AppInsight.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        protected ILogger<ValuesController> Logger { get; }


        public ValuesController(ILogger<ValuesController> logger)
        {
            Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        //public RuleValidator(IServiceProvider serviceProvider, IMessageReader messageHelper, IRequestContext requestContextAccessor, ILogger<RuleValidator> logger)
        //{
        //    Rules = new List<Tuple<Type, Delegate, string>>();
        //    this.ServiceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        //    this.MessageHelper = messageHelper ?? throw new ArgumentNullException(nameof(messageHelper));
        //    this.RequestContextAccessor = requestContextAccessor ?? throw new ArgumentNullException(nameof(requestContextAccessor));
        //    this.Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        //}

        // GET api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {

            return new string[] { "value-01", "value-002", "value-0003", "value-00004", "value-000005" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            Logger.LogInformation(
                "Ramis Information Logging Test: time: {Time} id: {id-value}",
                DateTime.Now, id);

            Logger.LogInformation("Ramis Logging Test Info from ValuesController - Errors {error-time}", DateTime.Now);
            Logger.LogError("Ramis Logging Test Error from ValuesController - Errors {time}", DateTime.Now);

            return "value abc " + id;
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
