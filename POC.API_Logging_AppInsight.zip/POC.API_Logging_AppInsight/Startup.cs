﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;

namespace POC.API_Logging_AppInsight
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // The following line enables Application Insights telemetry collection.
            //services.AddApplicationInsightsTelemetry();
            var appInsightsKey = "b4b9f28c-79ae-4183-b778-1e87d52ef8c4";
            services.AddApplicationInsightsTelemetry(appInsightsKey).AddLogging(logging => logging.AddFilter<ApplicationInsightsLoggerProvider>(string.Empty,LogLevel.Information));


            //you can also use TelemetryClient 
            //_appInsightsClient = new TelemetryClient();
            //_appInsightsClient.InstrumentationKey = ConfigManager.Insights_Key;
            // https://www.codeproject.com/Tips/1044948/Logging-with-ApplicationInsights



            //var appInsightsKey = hostBuilder.Configuration.GetSection("ApplicationInsights").GetValue<string>("InstrumentationKey");
            //var logLevel = (LogLevel)hostBuilder.Configuration.GetSection("ApplicationInsights").GetValue<int>("LogLevel");
            //services.AddApplicationInsightsTelemetry(appInsightsKey).AddLogging(logging => logging.AddFilter<ApplicationInsightsLoggerProvider>(string.Empty, logLevel));


            //var appInsightsKey = hostBuilder.Configuration.GetSection("ApplicationInsights").GetValue<string>("InstrumentationKey");
            //var logLevel = (LogLevel)hostBuilder.Configuration.GetSection("ApplicationInsights").GetValue<int>("LogLevel");

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();
        }
    }
}
