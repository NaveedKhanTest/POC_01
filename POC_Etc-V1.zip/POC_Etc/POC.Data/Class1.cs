﻿using System;

namespace POC.Data
{
    public class Class1
    {
    }
}
