﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace POC.Data.Models

{
    public partial class BloggingDbContext : DbContext
    {
        //https://stackoverflow.com/questions/52592820/how-to-configure-global-query-filters-in-a-database-first-approach
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // modify the generated code(change the generated OnModelCreating signatur to OnModelCreatingInternal and remove the override)
            OnModelCreatingInternal(modelBuilder);
            //modelBuilder.Entity<Blog>().Property<string>("TenantId").HasField("

            modelBuilder.Entity<Blogs>().HasQueryFilter(b => (!b.IsDeleted.HasValue || !b.IsDeleted.Value));
            //modelBuilder.Entity<Posts>().HasQueryFilter(p => !p.IsDeleted);
            //modelBuilder.Entity<Blog>().HasQueryFilter(b => EF.Property<string>(b, "TenantId") == _tenantId);
        }
    }

}