﻿using System;
using System.Collections.Generic;

namespace POC.Data.Models
{
    public partial class Posts
    {
        public int PostsId { get; set; }
        public int BlogsId { get; set; }
        public int AuthorsId { get; set; }
        public string Content { get; set; }
        public string Title { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public virtual Authors Authors { get; set; }
        public virtual Blogs Blogs { get; set; }
    }
}
