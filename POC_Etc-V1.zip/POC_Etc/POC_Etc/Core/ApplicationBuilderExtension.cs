﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core
{
    using System.Linq;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Mvc.ApiExplorer;
    using POC_Etc.API.Core.Middleware;

    /// <summary>
    /// ApplicationBuilderExtension
    /// </summary>
    public static class ApplicationBuilderExtension
    {
        /// <summary>
        /// ConfigureApplicationBuilder
        /// </summary>
        /// <param name="app">IApplicationBuilder</param>
        /// <param name="apiVersionDescriptionProvider">IApiVersionDescriptionProvider</param>
        public static void ConfigureApplicationBuilder(this IApplicationBuilder app, IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(
                options =>
                {
                    // build a swagger endpoint for each discovered API version
                    foreach (var description in apiVersionDescriptionProvider.ApiVersionDescriptions.OrderByDescending(x => x.GroupName))
                    {
                        options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName);
                    }
                    options.RoutePrefix = string.Empty;
                });

            // we need to be able to rewind requests and responsed for logging.
            app.UseMiddleware<RewindableBodyMiddleware>();

            // Register SystemActivitiesHandler
            //app.UseMiddleware<SystemActivitiesHandler>();

            //// Middleware registration order is important
            //// Register custom middleware for custom error handling
            //app.UseMiddleware<CustomExceptionHandler>();

            // Register AddResponseHeadersMiddleware
            app.UseMiddleware<AddResponseHeadersMiddleware>();

            // Register LoadRequestContextAccessor middleware
            app.UseMiddleware<ContextHandler>();

            // support for x-forwared-proto, x-forwarded-host, x-forwarded-for (ip)
            app.UseForwardedHeaders();

            // support for x-forwarded-pathbase so we generate urls that work on the client.
            app.UseMiddleware<ForwaredPathBaseMiddleware>();

            app.UseMvc();
        }
    }
}
