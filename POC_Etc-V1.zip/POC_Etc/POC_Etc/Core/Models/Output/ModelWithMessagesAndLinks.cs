﻿using Newtonsoft.Json;
using POC_Etc.API.Core.Models.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models.Output
{
    public class ModelWithMessagesAndLinks : IMessages, ILinks
    {
        /// <inheritdoc/>
        [JsonProperty(PropertyName = "links", Order = 998)]
        public IList<Link> Links { get; set; } = new List<Link>();

        /// <inheritdoc/>
        [JsonProperty(PropertyName = "messages", Order = 999)]
        public List<MessageModel> Messages { get; set; } = new List<MessageModel>();
    }
}
