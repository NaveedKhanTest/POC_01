﻿using Newtonsoft.Json;
using POC_Etc.API.Core.Models.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models
{
    public class ModelStateResultModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ModelStateResultModel"/> class.
        /// </summary>
        public ModelStateResultModel()
        {
            Messages = new List<MessageModel>();
        }

        /// <summary>
        /// Message list
        /// </summary>
        [JsonProperty(PropertyName = "messages")]
        public List<MessageModel> Messages { get; set; }
    }
}