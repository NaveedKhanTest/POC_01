﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models.Messages
{
    public enum SeverityType
    {
        /// <summary>
        /// Error
        /// </summary>
        Error,

        /// <summary>
        /// Info
        /// </summary>
        Info,

        /// <summary>
        /// Warning
        /// </summary>
        Warning
    }
}
