﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models.Messages
{
    public interface IMessages
    {
        /// <summary>
        /// Gets or sets the messages.
        /// </summary>
        List<MessageModel> Messages { get; set; }
    }
}
