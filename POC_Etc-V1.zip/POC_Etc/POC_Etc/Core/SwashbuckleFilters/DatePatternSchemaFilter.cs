﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.SwashbuckleFilters
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Reflection;
    using Swashbuckle.AspNetCore.Swagger;
    using Swashbuckle.AspNetCore.SwaggerGen;

    /// <summary>
    /// DataAnnotationSchemaFilter
    /// </summary>
    public class DatePatternSchemaFilter : ISchemaFilter
    {
        /// <inheritdoc/>
        public void Apply(Schema schema, SchemaFilterContext schemaFilterContext)
        {
            var type = schemaFilterContext.SystemType;

            var properties = type.GetProperties();

            foreach (var property in properties)
            {
                foreach (var attribute in property.GetCustomAttributes(typeof(DataTypeAttribute)))
                {
                    var dataType = ((DataTypeAttribute)attribute).DataType;
                    if (dataType == DataType.Date)
                    {
                        foreach (var item in schema.Properties)
                        {
                            if (item.Value != null && item.Value.Format == "date")
                            {
                                item.Value.Pattern = "yyyy-MM-dd";
                            }
                        }
                    }
                }
            }
        }
    }
}
