﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.SwashbuckleFilters
{
    using System.Linq;
    using POC.Domain;
    using Swashbuckle.AspNetCore.Swagger;
    using Swashbuckle.AspNetCore.SwaggerGen;

    /// <summary>
    /// Add header values for all the APIs for generated Swagger
    /// </summary>
    public class AddCommonHttpRequestHeaders : IOperationFilter
    {
        /// <summary>
        /// Add header parameters
        /// </summary>
        /// <param name="operation">operation</param>
        /// <param name="context">context</param>
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.Responses != null && operation.Responses.Any())
            {
                foreach (var item in operation.Responses)
                {
                    if (operation.Tags.Contains("SupportsPagedResults"))
                    {
                        operation.Parameters.Add(new NonBodyParameter
                        {
                            Name = HeaderConstant.PaginationPage,
                            In = "header",
                            Type = "string",
                            Required = false,
                            Description = $"String representation of page number as an integer value. Provide this header to return paged results sorted by uid ascending. Invalid header value will return page number 1 with default page size. If this header is not provided all records will be returned"
                        });

                        operation.Parameters.Add(new NonBodyParameter
                        {
                            Name = HeaderConstant.PaginationPageSize,
                            In = "header",
                            Type = "string",
                            Required = false,
                            Description = $"String representation of page size as an integer value. This header value is used along with header {HeaderConstant.PaginationPage} value. If header {HeaderConstant.PaginationPage} is not found this header value is ignored. Invalid header value will return requested page number 1 with default page size"
                        });

                        break;
                    }
                }
            }

           

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = "HeaderConstant.ClintTimeStamp",
                In = "header",
                Type = "string",
                Required = true,
                Format = "date-time",
                Description = "The String and timestamp when slient sends the request to API."
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = HeaderConstant.ProviderCode,
                In = "header",
                Type = "string",
                Required = true,
                Description = "The unique code of the api client as supplied by API when the organisation was registered as a client"
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = HeaderConstant.ApiClientName,
                In = "header",
                Type = "string",
                Required = true,
                Description = "The name of the organisation as registered with API."
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = HeaderConstant.UserNameType,
                In = "header",
                Type = "string",
                Required = true,
                Description = "The client type category for which the api client is classified when registered with API."
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = HeaderConstant.UserName,
                In = "header",
                Type = "string",
                Required = true,
                Description = "The login name of user."
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = HeaderConstant.MessageId,
                In = "header",
                Type = "string",
                Required = true,
                Description = "The unique identified that has been allocated by client."
            });
        }
    }
}
