﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.SwashbuckleFilters
{
    using System.Collections.Generic;
    using System.Linq;
    using POC.Domain;
    using Swashbuckle.AspNetCore.Swagger;
    using Swashbuckle.AspNetCore.SwaggerGen;

    /// <summary>
    /// Add Response Headers SwaggerGen Operation Filter
    /// </summary>
    public class AddResponseHeadersFilter : IOperationFilter
    {
        /// <inheritdoc/>
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.Responses != null && operation.Responses.Any())
            {
                foreach (var item in operation.Responses)
                {
                    if (item.Value != null)
                    {
                        if (item.Value.Headers == null)
                        {
                            item.Value.Headers = new Dictionary<string, Header>();
                        }

                        var timestampHeader = new Header() { Type = "string", Description = "The timestamp when the response is generated" };
                        var messageidHeader = new Header() { Type = "string", Description = "The unique identifier that has been allocated by DHS to the submitted request." };

                        item.Value.Headers.Add(HeaderConstant.StringTimeStamp, timestampHeader);
                        item.Value.Headers.Add(HeaderConstant.MessageId, messageidHeader);

                        var paginationRequestedPage = new Header() { Type = "string", Description = $"Value from request header {HeaderConstant.PaginationPage}" };
                        var paginationRequestedPageSize = new Header() { Type = "string", Description = $"Value from request header {HeaderConstant.PaginationPageSize}" };
                        var paginationPage = new Header() { Type = "string", Description = "Paged Response page number" };
                        var paginationPageSize = new Header() { Type = "string", Description = "Paged Response page size" };
                        var paginationPageCount = new Header() { Type = "string", Description = "Paged Response total page count" };
                        var paginationRecordCount = new Header() { Type = "string", Description = "Paged Response total record count" };
                        var paginationPrevious = new Header() { Type = "string", Description = "Paged Response previous page number" };
                        var paginationNext = new Header() { Type = "string", Description = "Paged Response next page number" };

                        if (operation.Tags.Contains("SupportsPagedResults"))
                        {
                            item.Value.Headers.Add(HeaderConstant.PaginationRequestedPage, paginationRequestedPage);
                            item.Value.Headers.Add(HeaderConstant.PaginationRequestedPageSize, paginationRequestedPageSize);
                            item.Value.Headers.Add(HeaderConstant.PaginationPage, paginationPage);
                            item.Value.Headers.Add(HeaderConstant.PaginationPageSize, paginationPageSize);
                            item.Value.Headers.Add(HeaderConstant.PaginationPageCount, paginationPageCount);
                            item.Value.Headers.Add(HeaderConstant.PaginationRecordCount, paginationRecordCount);
                            item.Value.Headers.Add(HeaderConstant.PaginationPreviousPage, paginationPrevious);
                            item.Value.Headers.Add(HeaderConstant.PaginationNextPage, paginationNext);
                        }
                    }
                }
            }
        }
    }
}