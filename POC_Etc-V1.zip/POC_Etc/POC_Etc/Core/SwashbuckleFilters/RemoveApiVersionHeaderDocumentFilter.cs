﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.SwashbuckleFilters
{
    using System.Linq;

    using Swashbuckle.AspNetCore.SwaggerGen;
    using System.Linq;
    using Swashbuckle.AspNetCore.Swagger;
    using Swashbuckle.AspNetCore.SwaggerGen;
    using POC.Domain;

    /// <summary>
    /// RemoveApiVersionHeaderDocumentFilter:
    /// api-version request header is where we get the api version (1.0 ,2.0 etc) from
    /// but this request header will be added by APIM we do not want this to advertised
    /// in the swagger, this filter removes api-version request header from generated
    /// swagger document
    /// </summary>
    public class RemoveApiVersionHeaderDocumentFilter : IDocumentFilter //, IScopedService
    {
        // <inheritdoc/>
        public void Apply(SwaggerDocument swaggerDoc, DocumentFilterContext context)
        {
            swaggerDoc.Paths = swaggerDoc.Paths.ToDictionary(
                     entry => entry.Key,
                     entry =>
                     {
                         var pathItem = entry.Value;
                         RemoveVersionParamFrom(pathItem.Get);
                         RemoveVersionParamFrom(pathItem.Put);
                         RemoveVersionParamFrom(pathItem.Post);
                         RemoveVersionParamFrom(pathItem.Delete);
                         RemoveVersionParamFrom(pathItem.Options);
                         RemoveVersionParamFrom(pathItem.Head);
                         RemoveVersionParamFrom(pathItem.Patch);
                         return pathItem;
                     });
        }



        private void RemoveVersionParamFrom(Operation operation)
        {
            if (operation == null || operation.Parameters == null)
            {
                return;
            }

            var headerVersionParam = operation.Parameters.FirstOrDefault(param => param.Name == HeaderConstant.ApiVersion && param.In == "header");
            if (headerVersionParam != null)
            {
                operation.Parameters.Remove(headerVersionParam);
            }

            var queryVersionParam = operation.Parameters.FirstOrDefault(param => param.Name == HeaderConstant.ApiVersion && param.In == "query");
            if (queryVersionParam != null)
            {
                operation.Parameters.Remove(queryVersionParam);
            }
        }
    }
}
