﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.CustomFilters
{
    using System;
    using System.Linq;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using POC_Etc.API.Core.Models;
    using POC_Etc.API.Core.Models.Messages;

    /// <summary>
    /// Custom filter that will be invoked globally to perform model state validation
    /// </summary>
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateModelAttribute"/> class.
        /// </summary>
        /// <param name="messageHelper">messageHelper</param>
        public ValidateModelAttribute()
        // Use MessageReader to read some description from db
        //public ValidateModelAttribute(IMessageReader messageHelper)
        {
            //this.MessageHelper = messageHelper ?? throw new ArgumentNullException(nameof(messageHelper));
        }

        ///// <summary>
        ///// MessageHelper to get messages
        ///// </summary>
        //protected IMessageReader MessageHelper { get; set; }

        /// <inheritdoc/>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                var modelStateResultModel = new ModelStateResultModel();

                var keys = context.ModelState.Keys;

                foreach (var key in keys.Distinct())
                {
                    if (!string.IsNullOrEmpty(key))
                    {
                        //var message = this.MessageHelper.GetMessage(MessageConstant.M00001SYS, key).Result;
                        var message = new MessageModel();
                        message.Description = "error in ValidateModelAttribute 123";
                        message.Severity = "Critical";

                        modelStateResultModel.Messages.Add(message);
                    }
                    //else
                    //{
                    //    modelStateResultModel.Messages.Add(this.MessageHelper.GetMessage(MessageConstant.M00002SYS).Result);
                    //}
                }

                context.Result = new BadRequestObjectResult(modelStateResultModel);
            }
        }
    }
}
