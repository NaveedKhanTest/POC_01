﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.CustomFilters
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.JsonPatch;
    using Microsoft.AspNetCore.JsonPatch.Operations;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Morcatko.AspNetCore.JsonMergePatch;

    /// <summary>
    /// PatchDocumentEmptyToNullConverter
    /// </summary>
    public class PatchDocumentEmptyToNullConverter : IActionFilter
    {
        /// <inheritdoc/>
        public void OnActionExecuted(ActionExecutedContext context)
        {
        }

        /// <inheritdoc/>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            var actionArguments = context.ActionArguments;

            if (actionArguments != null && actionArguments.Values != null && actionArguments.Values.Any())
            {
                foreach (var item in actionArguments.Values)
                {
                    // look for JsonMergePatchDocument
                    if (IsJsonMergePatchDocumentType(item.GetType()))
                    {
                        foreach (var property in item.GetType().GetProperties())
                        {
                            var pValue = property.GetValue(item);

                            // look for JsonPatchDocument
                            if (pValue != null && IsJsonPatchDocumentType(pValue.GetType()))
                            {
                                foreach (var pValueProperty in pValue.GetType().GetProperties())
                                {
                                    var pValueValue = pValueProperty.GetValue(pValue);

                                    // look for JsonPatchOperation
                                    if (pValueValue != null && IsJsonPatchOperation(pValueValue.GetType()))
                                    {
                                        var oList = pValueValue as IList;

                                        foreach (var oListItem in oList)
                                        {
                                            // retrive value property
                                            var valueProperty = oListItem.GetType().GetProperty("value");

                                            if (valueProperty != null)
                                            {
                                                // set the value to null if the existing value is empty or whitespace
                                                var v = valueProperty.GetValue(oListItem);
                                                if (v != null && string.IsNullOrWhiteSpace(v.ToString()))
                                                {
                                                    valueProperty.SetValue(oListItem, null);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private bool IsJsonMergePatchDocumentType(Type t) => (t != null) && t.IsGenericType && (t.GetGenericTypeDefinition() == typeof(JsonMergePatchDocument<>));

        private bool IsJsonPatchDocumentType(Type t) => (t != null) && t.IsGenericType && (t.GetGenericTypeDefinition() == typeof(JsonPatchDocument<>));

        private bool IsJsonPatchOperation(Type t) => (t != null) && t.IsGenericType;
    }
}
