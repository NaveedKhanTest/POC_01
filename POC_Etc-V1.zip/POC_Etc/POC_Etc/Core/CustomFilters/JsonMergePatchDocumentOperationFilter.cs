﻿using System;
using System.Collections.Generic;
using Morcatko.AspNetCore.JsonMergePatch;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

/// <summary>
/// Filter class used by Json Merge opetaions in controllers
/// </summary>
public class JsonMergePatchDocumentOperationFilter : IOperationFilter
{
    /// <summary>
    /// Apply
    /// </summary>
    /// <param name="operation">operation</param>
    /// <param name="context">OperationFilterContext</param>
    public void Apply(Swashbuckle.AspNetCore.Swagger.Operation operation, OperationFilterContext context)
    {
        if ((context.ApiDescription.ParameterDescriptions.Count > 0) && (context.ApiDescription.ParameterDescriptions.Count != operation.Parameters.Count))
        {
            throw new NotSupportedException("Something went wrong. Parameter counts do not match");
        }

        for (int i = 0; i < context.ApiDescription.ParameterDescriptions.Count; i++)
        {
            var parameter = context.ApiDescription.ParameterDescriptions[i];
            if (IsJsonMergePatchDocumentType(parameter.Type))
            {
                (operation.Parameters[i] as BodyParameter).Schema = context.SchemaRegistry.GetOrRegister(parameter.Type.GenericTypeArguments[0]);
            }
            else if ((parameter.Type != null) && parameter.Type.IsGenericType && (parameter.Type.GetGenericTypeDefinition() == typeof(IEnumerable<>)))
            {
                var jsonMergeType = parameter.Type.GenericTypeArguments[0];
                if (IsJsonMergePatchDocumentType(jsonMergeType))
                {
                    var enumerableType = typeof(IEnumerable<>);
                    var genericEnumerableType = enumerableType.MakeGenericType(jsonMergeType.GenericTypeArguments[0]);
                    (operation.Parameters[i] as BodyParameter).Schema = context.SchemaRegistry.GetOrRegister(genericEnumerableType);
                }
            }
        }
    }

    private static bool IsJsonMergePatchDocumentType(Type t) => (t != null) && t.IsGenericType && (t.GetGenericTypeDefinition() == typeof(JsonMergePatchDocument<>));
}

