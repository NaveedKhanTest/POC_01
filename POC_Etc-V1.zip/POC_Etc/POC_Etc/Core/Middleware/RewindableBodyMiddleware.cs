﻿
namespace POC_Etc.API.Core.Middleware
{
    using System;
    using System.IO;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// Middleware so we can rewind reqeusts and responses.
    /// </summary>
    public class RewindableBodyMiddleware
    {
        private readonly RequestDelegate next;

        /// <summary>
        /// Initializes a new instance of the <see cref="RewindableBodyMiddleware"/> class.
        /// </summary>
        /// <param name="next">RequestDelegate</param>
        public RewindableBodyMiddleware(RequestDelegate next)
        {
            this.next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Covnerts the request and response body to memory streams.
        /// </summary>
        /// <param name="context">context</param>
        /// <returns>A <see cref="Task"/> representing the result of the asynchronous operation.</returns>
        public async Task Invoke(HttpContext context)
        {
            var originalResponseBodyStream = context.Response.Body;

            using (var responseBody = new MemoryStream())
            {
                try
                {
                    context.Response.Body = responseBody;

                    // make sure the httprequest.body is seekable, if not copy it to a new stream and replace the body.
                    // if a stream is not seekable and we read it we cant read it again
                    // the request.EnableRewind(); isn't working, it should be copying to a temp file but this doesnt appear to be working.
                    // maybe this is due to service fabric and the NETWORK SERVICE identity being used.
                    var canSeek = context.Request.Body.CanSeek;
                    if (!canSeek)
                    {
                        using (var requestBody = new MemoryStream())
                        {
                            await context.Request.Body.CopyToAsync(requestBody);
                            requestBody.Position = 0;
                            context.Request.Body = requestBody;
                            await next(context);
                        }
                    }
                    else
                    {
                        await next(context);
                    }
                }
                finally
                {
                    responseBody.Position = 0;
                    await responseBody.CopyToAsync(originalResponseBodyStream);
                    context.Response.Body = originalResponseBodyStream;
                }
            }
        }
    }
}
