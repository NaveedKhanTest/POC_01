﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Middleware
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// Middleware to use the x-forwarded-pathbase header as the request.pathbase.
    /// </summary>
    public class ForwaredPathBaseMiddleware
    {
        private readonly RequestDelegate next;

        private readonly string xForwardedPathbase = "X-Forwarded-PathBase";

        /// <summary>
        /// Initializes a new instance of the <see cref="ForwaredPathBaseMiddleware"/> class.
        /// </summary>
        /// <param name="next">The delegate representing the next middleware in the request pipeline.</param>
        public ForwaredPathBaseMiddleware(RequestDelegate next)
        {
            this.next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Executes the middleware.
        /// </summary>
        /// <param name="context">The <see cref="HttpContext"/> for the current request.</param>
        /// <returns>A task that represents the execution of this middleware.</returns>
        public async Task Invoke(HttpContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            if (context.Request.Headers.ContainsKey(xForwardedPathbase))
            {
                var originalPath = context.Request.Path;
                var originalPathBase = context.Request.PathBase;

                var pathBase = context.Request.Headers[xForwardedPathbase].Single();
                context.Request.PathBase = originalPathBase.Add(pathBase);

                try
                {
                    await this.next(context);
                }
                finally
                {
                    context.Request.Path = originalPath;
                    context.Request.PathBase = originalPathBase;
                }
            }
            else
            {
                await this.next(context);
            }
        }
    }
}
