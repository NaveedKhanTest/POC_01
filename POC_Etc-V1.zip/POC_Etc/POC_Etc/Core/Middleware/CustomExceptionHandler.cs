﻿
//namespace POC_Etc.API.Core.Middleware
//{
//    using System;
//    using System.Collections.Generic;
//    using System.ComponentModel.DataAnnotations;
//    using System.Net;
//    using System.Threading.Tasks;

//    using Microsoft.AspNetCore.Http;
//    using Microsoft.AspNetCore.JsonPatch.Exceptions;
//    using Newtonsoft.Json;
//    using POC_Etc.API.Core.Exceptions;
//    using POC_Etc.API.Core.Models.Messages;

//    /// <summary>
//    /// Custom Error Handler Class
//    /// </summary>
//    public class CustomExceptionHandler
//    {
//        private readonly RequestDelegate next;

//        /// <summary>
//        /// Initializes a new instance of the <see cref="CustomExceptionHandler"/> class.
//        /// </summary>
//        /// <param name="next">RequestDelegate</param>
//        public CustomExceptionHandler(RequestDelegate next)
//        {
//            this.next = next ?? throw new ArgumentNullException(nameof(next));
//        }

//        /// <summary>
//        /// Task
//        /// </summary>
//        /// <param name="context">context</param>
//        /// <param name="systemActivitiesCommands">systemActivitiesCommands</param>
//        /// <param name="messageReader">messageReader to get message from database</param>
//        /// <returns>A <see cref="Task"/> representing the result of the asynchronous operation.</returns>
//        public async Task Invoke(HttpContext context, ISystemActivitiesCommands systemActivitiesCommands, IMessageReader messageReader)
//        {
//            try
//            {
//                await next(context);
//            }
//            catch (Exception ex)
//            {
//                await HandleExceptionAsync(context, ex, systemActivitiesCommands, messageReader);
//            }
//        }

//        private static async Task HandleExceptionAsync(HttpContext context, Exception exception, ISystemActivitiesCommands systemActivitiesCommands, IMessageReader messageReader)
//        {
//            string result = string.Empty;
//            context.Response.ContentType = "application/json";
//            switch (exception)
//            {
//                case POC_Etc.API.Core.Exceptions.ValidationException _:
//                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    var valException = (POC_Etc.API.Core.Exceptions.ValidationException)exception;
//                    result = JsonConvert.SerializeObject(new MessageValuesModel() { Messages = valException.Messages });
//                    break;
//                case MissingRecordException _:
//                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
//                    var mException = (System.ComponentModel.DataAnnotations.ValidationException)exception;
//                    result = JsonConvert.SerializeObject(new MessageValuesModel() { Messages = mException.Messages });
//                    break;
//                case NotFoundException _:
//                    context.Response.StatusCode = (int)HttpStatusCode.NotFound;
//                    break;
//                //case JsonPatchException _:
//                //    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
//                //    var messages = new List<MessageModel>
//                //    {
//                //        await messageReader.GetMessage"error No", exception.Message)
//                //    };
//                //    result = JsonConvert.SerializeObject(new MessageValuesModel() { Messages = messages });
//                //    break;
//                default:
//                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

//                    // TODO: Only log the exception to the database and send friendly message to the client
//                    // consider doing this APIM
//                    result = exception.ToString();
//                    break;
//            }

//            await context.Response.WriteAsync(result);
//        }
//    }
//}
