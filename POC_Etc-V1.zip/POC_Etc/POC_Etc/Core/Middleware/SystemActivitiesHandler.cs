﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace POC_Etc.API.Core.Middleware
//{
//    using System;
//    using System.Net;
//    using System.Threading.Tasks;
//    //using My.Application.Commands;
//    using Microsoft.AspNetCore.Http;

//    /// <summary>
//    /// SystemActivities Handler create system activities entires for each request response
//    /// </summary>
//    public class SystemActivitiesHandler
//    {
//        private readonly RequestDelegate next;

//        /// <summary>
//        /// Initializes a new instance of the <see cref="SystemActivitiesHandler"/> class.
//        /// </summary>
//        /// <param name="next">RequestDelegate</param>
//        public SystemActivitiesHandler(RequestDelegate next)
//        {
//            this.next = next ?? throw new ArgumentNullException(nameof(next));
//        }

//        /// <summary>
//        /// Task
//        /// </summary>
//        /// <param name="context">context</param>
//        /// <param name="systemActivitiesCommands">systemActivitiesCommands</param>
//        /// <returns>A <see cref="Task"/> representing the result of the asynchronous operation.</returns>
//        public async Task Invoke(HttpContext context, ISystemActivitiesCommands systemActivitiesCommands)
//        {
//            var message = string.Empty;
//            try
//            {
//                try
//                {
//                    await systemActivitiesCommands.CreateActivity(context.Request);
//                }
//                catch (Exception ex)
//                {
//                    // Add details to identify where the exception occured in system acivity
//                    message = $"CreateSystemActivity Exception: {ex.ToString()}";
//                    throw;
//                }

//                // any exception here will be handled by CustomException Handler
//                await next(context);

//                try
//                {
//                    await systemActivitiesCommands.UpdateActivity(context.Response);
//                }
//                catch (Exception ex)
//                {
//                    // Add details to identify where the exception occured in system acivity
//                    message = $"UpdateSystemActivity Exception: {ex.ToString()}";
//                    throw;
//                }
//            }
//            catch
//            {
//                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
//                await context.Response.WriteAsync(message);
//            }
//        }
//    }
//}