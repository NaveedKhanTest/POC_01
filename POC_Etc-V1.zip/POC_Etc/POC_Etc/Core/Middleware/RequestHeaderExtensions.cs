﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.AspNetCore.Http
{
    using System.Linq;

    /// <summary>
    /// RequestHeaderExtensions
    /// </summary>
    public static class RequestHeaderExtensions
    {
        /// <summary>
        /// Get Header Value by Header Name
        /// </summary>
        /// <param name="keyValuePairs">IHeaderDictionary</param>
        /// <param name="headerName">header name</param>
        /// <returns>string value if header found otherwise null</returns>
        public static string GetHeaderValue(this IHeaderDictionary keyValuePairs, string headerName)
        {
            var key = keyValuePairs.Keys.FirstOrDefault(n => n.Equals(headerName));

            if (key != null)
            {
                return keyValuePairs[key].ToString();
            }

            return null;
        }
    }
}
