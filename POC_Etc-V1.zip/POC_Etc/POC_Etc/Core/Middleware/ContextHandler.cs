﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Middleware
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Primitives;
    using POC.Domain;
    using POC_Etc.API.Core.Exceptions;
    using POC_Etc.API.Core.Models.Messages;

    /// <summary>
    /// Loads reqeust context accessor members from request context
    /// </summary>
    public class ContextHandler
    {
        private readonly RequestDelegate next;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextHandler"/> class.
        /// </summary>
        /// <param name="next">RequestDelegate</param>
        public ContextHandler(RequestDelegate next)
        {
            this.next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Task
        /// </summary>
        /// <param name="context">context</param>
        /// <param name="loadRequestContextAccessorCommand">loadRequestContextAccessorCommand</param>
        /// <returns>A <see cref="Task"/> representing the result of the asynchronous operation.</returns>
        public async Task Invoke(HttpContext context)
        //public async Task Invoke(HttpContext context, ILoadRequestContextAccessorCommand loadRequestContextAccessorCommand)
        {
            //loadRequestContextAccessorCommand.Execute();
            Execute();
            await next(context);
        }

        public void Execute()
        {
            var headers = this.httpContextAccessor.HttpContext.Request.Headers;

            this.RequestContextAccessor.UserType = GetHeaderValue("UserType", "MessageConstant.M00001");
            //this.RequestContextAccessor.UserName = GetUserNameValue(HeaderConstant.UserName, "M000025");
            this.RequestContextAccessor.MessageId = GetMessageIdValue(HeaderConstant.MessageId, "M00009");
            var providerTimeStamp = GetHeaderValue("ClientTimeStamp", "M000014");
            var dhsTimeStamp = GetHeaderValue("ApiCallTimeStamp", "000025");
            this.RequestContextAccessor.ClientTransactionTimestamp = GetValidDateTime(dhsTimeStamp, "M00004");
            //this.RequestContextAccessor.ClientTransactionTimestamp = GetValidDateTime(providerTimeStamp, "M000155");

            //if (!string.IsNullOrWhiteSpace(this.RequestContextAccessor.ProviderCode))
            //{
            //    var result = this.ProviderRepository.GetProviderByProviderCode(this.RequestContextAccessor.ProviderCode).Result;

            //    if (result != null)
            //    {
            //        this.RequestContextAccessor.ProviderUid = result.Uid1ProvidersResKey;

            //        // check if the provider type supplied it valid for the provider code
            //        var providerTypeList = ProviderRepository.GetProviderTypeByProviderCode().Result;
            //        if (!string.IsNullOrEmpty(this.RequestContextAccessor.ProviderType))
            //        {
            //            if (!(providerTypeList != null && providerTypeList.Any(x => x.ClientOrganisationTypeCode.ToLower() == this.RequestContextAccessor.ProviderType.ToLower())))
            //            {
            //                Messages.Add(GetMessageModel(MessageConstant.M00014SYS));
            //            }
            //        }
            //    }
            //    else
            //    {
            //        var msg = new MessageModel()
            //        {
            //            Description = "message desc",
            //        };
            //        Messages.Add(msg);
            //        //Messages.Add(GetMessageModel(MessageConstant.M00012SYS));
            //        this.RequestContextAccessor.UserType = null;
            //    }
            //}

            // throw validation exception if we have any messages.
            if (Messages.Any())
            {
                throw new ValidationException(Messages);
            }
        }

        private DateTime? GetValidDateTime(string timeStamp, string messageId)
        {
            if (!string.IsNullOrWhiteSpace(timeStamp))
            {
                if (DateTime.TryParse(timeStamp, out DateTime dateTime))
                {
                    return dateTime;
                }
                else
                {
                    //eroor
                    //Messages.Add(GetMessageModel(messageId));
                }
            }

            return null;
        }


        private string GetMessageIdValue(string headerName, string messageId)
        {
            string strHeaderValue = GetHeaderValue(headerName);

            if (string.IsNullOrWhiteSpace(strHeaderValue))
            {
                //Messages.Add(GetMessageModel(messageId));
                strHeaderValue = null;
            }
            else
            {
                if (strHeaderValue.Length > 100)
                {
                    //Messages.Add(GetMessageModel("0001"));
                    strHeaderValue = null;
                }
            }

            return strHeaderValue;
        }

        private string GetHeaderValue(string headerName, string messageId)
        {
            string strHeaderValue = GetHeaderValue(headerName);

            if (string.IsNullOrWhiteSpace(strHeaderValue))
            {
                //var errorMsg = new Message();
                //Messages.Add(GetMessageModel(messageId));
                strHeaderValue = null;
            }

            return strHeaderValue;
        }


        private string GetHeaderValue(string headerName)
        {
            string strHeaderValue = string.Empty;
            var headers = this.httpContextAccessor.HttpContext.Request.Headers;

            if (headers.TryGetValue(headerName, out StringValues headerValues))
            {
                strHeaderValue = headerValues.SingleOrDefault();
            }

            return strHeaderValue;
        }

        /// <summary>
        /// RequestContextAccessor
        /// </summary>
        protected IRequestContext RequestContextAccessor { get; set; }

        private readonly IHttpContextAccessor httpContextAccessor;
        protected List<MessageModel> Messages { get; set; }



    }
}