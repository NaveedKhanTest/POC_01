﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Middleware
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using POC.Domain;

    /// <summary>
    /// AddResponseHeadersMiddleware
    /// </summary>
    public class AddResponseHeadersMiddleware
    {
        private readonly RequestDelegate next;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddResponseHeadersMiddleware"/> class.
        /// </summary>
        /// <param name="next">RequestDelegate</param>
        public AddResponseHeadersMiddleware(RequestDelegate next)
        {
            this.next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Task
        /// </summary>
        /// <param name="context">context</param>
        /// <returns>A <see cref="Task"/> representing the result of the asynchronous operation.</returns>
        public async Task Invoke(HttpContext context)
        {
            var messageId = context.Request.Headers.GetHeaderValue(HeaderConstant.MessageId);

            await next(context);

            if (context.Response.Headers.ContainsKey(HeaderConstant.MessageId))
            {
                context.Response.Headers.Remove(HeaderConstant.MessageId);
            }

            context.Response.Headers.Add(HeaderConstant.MessageId, messageId);
            context.Response.Headers.Add(HeaderConstant.StringTimeStamp, DateTime.UtcNow.ToString("s") + "Z");
        }
    }
}
