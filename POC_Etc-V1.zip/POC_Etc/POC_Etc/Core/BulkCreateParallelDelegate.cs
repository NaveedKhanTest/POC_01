﻿namespace POC_Etc.API.Core
{
    using POC_Etc.API.Core.Models;
    using POC_Etc.API.Core.Models.Messages;
    using POC_Etc.API.V1.Models.Bulk;
    using System;
    using System.Collections.Async;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using System.Transactions;


    /// <summary>
    /// BulkCreateParallelDelegate
    /// </summary>
    public static class BulkCreateParallelDelegate
    {
        /// <summary>
        /// Bulk Create Invoke Method
        /// </summary>
        /// <typeparam name="TInput">type of BulkDataInputItem</typeparam>
        /// <typeparam name="TOutput">type of BulkDataOutputItem</typeparam>
        /// <typeparam name="T1">type of any post input model</typeparam>
        /// <typeparam name="T2">type of any post out model</typeparam>
        /// <param name="input">Any BulkPostInputModel</param>
        /// <param name="createDelegate">Create method to call for processing each bulkpostinputmodel item</param>
        /// <param name="messageHelper">messageHelper to reteive any required messages from database</param>
        /// <returns>relavant bulkpostoutputModel</returns>
        public static async Task<List<TOutput>> Invoke<TInput, TOutput, T1, T2>(IEnumerable<TInput> input, Func<T1, Task<CommandResult<T2>>> createDelegate)
            where TInput : BulkDataInputItem<T1>
            where TOutput : BulkDataOutputItem<T2>, new()
            where T1 : class
            where T2 : IMessages, new()
        {
            var result = await ProcessBulkCreateInputInParallel<TInput, TOutput, T1, T2>(input, createDelegate);
            return result.OrderBy(_ => _.Position).ToList();
        }

        /// <summary>
        /// Bulk Create Invoke Method
        /// </summary>
        /// <typeparam name="TInput">type of BulkDataInputItem</typeparam>
        /// <typeparam name="TOutput">type of BulkDataOutputItem</typeparam>
        /// <typeparam name="T1">type of any post input model</typeparam>
        /// <typeparam name="T2">type of any post out model</typeparam>
        /// <param name="input">Any BulkPostInputModel</param>
        /// <param name="createDelegate">Method to call for processing each bulkpostinputmodel item</param>
        /// <param name="messageHelper">messageHelper to reteive any required messages from database</param>
        /// <returns>relavant bulkpostoutputModel</returns>
        private static async Task<List<TOutput>> ProcessBulkCreateInput<TInput, TOutput, T1, T2>(IEnumerable<TInput> input, Func<T1, Task<CommandResult<T2>>> createDelegate)
            where TInput : BulkDataInputItem<T1>
            where TOutput : BulkDataOutputItem<T2>, new()
            where T1 : class
            where T2 : IMessages, new()
        {
            var resultList = new List<TOutput>();
            var itemPosition = 0;

            foreach (var item in input)
            {
                ++itemPosition;
                var resultData = new TOutput() { CorrelationId = item.CorrelationId, Position = itemPosition };

                try
                {
                    using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    {
                        var result = await createDelegate(item.Data);
                        resultData.Data = result.ResultValue;

                        if (result.ResultStatus == CommandStatus.Success)
                        {
                            resultData.StatusCode = (int)HttpStatusCode.OK;
                        }
                        else
                        {
                            resultData.StatusCode = (int)HttpStatusCode.BadRequest;
                        }

                        scope.Complete();
                    }
                }
                catch (Exception ex)
                {
                    //todo create a message and put like bellow
                    MessageModel message = new MessageModel();
                    message.Description = ex.Message;

                    resultData.Data.Messages.Add(message);
                    //resultData.Data.Messages.Add(messageHelper.GetMessage(MessageConstant.M00017SYS, ex.ToString()).Result);
                    resultData.StatusCode = (int)HttpStatusCode.InternalServerError;
                }

                resultList.Add(resultData);
            }

            return resultList;
        }

        /// <summary>
        /// Bulk Create Invoke Method
        /// </summary>
        /// <typeparam name="TInput">type of BulkDataInputItem</typeparam>
        /// <typeparam name="TOutput">type of BulkDataOutputItem</typeparam>
        /// <typeparam name="T1">type of any post input model</typeparam>
        /// <typeparam name="T2">type of any post out model</typeparam>
        /// <param name="input">Any BulkPostInputModel</param>
        /// <param name="createDelegate">Method to call for processing each bulkpostinputmodel item</param>
        /// <param name="messageHelper">messageHelper to reteive any required messages from database</param>
        /// <returns>relavant bulkpostoutputModel</returns>
        private static async Task<ConcurrentBag<TOutput>> ProcessBulkCreateInputInParallel<TInput, TOutput, T1, T2>(IEnumerable<TInput> input, Func<T1, Task<CommandResult<T2>>> createDelegate)
            where TInput : BulkDataInputItem<T1>
            where TOutput : BulkDataOutputItem<T2>, new()
            where T1 : class
            where T2 : IMessages, new()
        {
            var resultList = new ConcurrentBag<TOutput>();

            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                // install nuget package AsyncEnumerator 
                // Install-Package AsyncEnumerator -Version 2.2.2
                await input.ParallelForEachAsync(async (item, itemPosition) =>
                {
                    var resultData = new TOutput() { CorrelationId = item.CorrelationId, Position = itemPosition };

                    var result = await createDelegate(item.Data);
                    resultData.Data = result.ResultValue;

                    if (result.ResultStatus == CommandStatus.Success)
                    {
                        resultData.StatusCode = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        resultData.StatusCode = (int)HttpStatusCode.BadRequest;
                    }

                    resultList.Add(resultData);
                });

                scope.Complete();
            }

            return resultList;
        }
    }
}