﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Exceptions
{
    using POC_Etc.API.Core.Models.Messages;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Exception thrown if resource is not found
    /// </summary>
    public class MissingRecordException : ApplicationException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MissingRecordException"/> class.
        /// </summary>
        public MissingRecordException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MissingRecordException"/> class.
        /// </summary>
        /// <param name="messages">list of MessageViewModel</param>
        public MissingRecordException(List<MessageModel> messages)
        {
            Messages = messages;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MissingRecordException"/> class.
        /// </summary>
        /// <param name="message">MessageViewModel</param>
        public MissingRecordException(MessageModel message)
        {
            var messageList = new List<MessageModel>
            {
                message
            };
            Messages = messageList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MissingRecordException"/> class.
        /// </summary>
        /// <param name="messages">MessageViewModel array</param>
        public MissingRecordException(params MessageModel[] messages)
        {
            if (messages == null)
            {
                throw new NullReferenceException();
            }

            Messages = messages.ToList();
        }

        /// <summary>
        /// Collection of messages
        /// </summary>
        public List<MessageModel> Messages { get; }
    }
}