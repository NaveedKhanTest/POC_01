﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Exceptions
{
    using POC_Etc.API.Core.Models.Messages;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Exception thrown if resource is not found
    /// </summary>
    public class NotFoundException : ApplicationException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NotFoundException"/> class.
        /// </summary>
        public NotFoundException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotFoundException"/> class.
        /// </summary>
        /// <param name="messages">list of MessageViewModel</param>
        public NotFoundException(List<MessageModel> messages)
        {
            Messages = messages;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotFoundException"/> class.
        /// </summary>
        /// <param name="message">MessageViewModel</param>
        public NotFoundException(MessageModel message)
        {
            var messageList = new List<MessageModel>
            {
                message
            };
            Messages = messageList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotFoundException"/> class.
        /// </summary>
        /// <param name="messages">MessageViewModel array</param>
        public NotFoundException(params MessageModel[] messages)
        {
            if (messages == null)
            {
                throw new NullReferenceException();
            }

            Messages = messages.ToList();
        }

        /// <summary>
        /// Collection of messages
        /// </summary>
        public List<MessageModel> Messages { get; }
    }
}
