﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Exceptions
{
    using POC_Etc.API.Core.Models.Messages;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Exception class that will be thrown in case of any business rule validation
    /// </summary>
    public class ValidationException : ApplicationException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationException"/> class.
        /// </summary>
        /// <param name="messages">list of MessageViewModel</param>
        public ValidationException(List<MessageModel> messages)
        {
            Messages = messages;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationException"/> class.
        /// </summary>
        /// <param name="message">MessageViewModel</param>
        public ValidationException(MessageModel message)
        {
            var messageList = new List<MessageModel>
            {
                message
            };
            Messages = messageList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationException"/> class.
        /// </summary>
        /// <param name="messages">MessageViewModel array</param>
        public ValidationException(params MessageModel[] messages)
        {
            if (messages == null)
            {
                throw new NullReferenceException();
            }

            Messages = messages.ToList();
        }

        /// <summary>
        /// Collection of messages
        /// </summary>
        public List<MessageModel> Messages { get; }

        // public override string Message => Messages.Any() ? Newtonsoft.Json.JsonConvert.SerializeObject(new { Messages }) : base.Message;
    }
}
