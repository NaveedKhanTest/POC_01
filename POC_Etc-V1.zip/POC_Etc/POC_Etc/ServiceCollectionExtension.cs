﻿using POC_Etc.API.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ServiceCollectionExtension
    {
        /// <summary>
        /// RegisterStudentAPIServices uses Scrutor to register
        /// concrete classes by scanning the assemblies of type IScopedService
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        /// <returns>IServiceCollection with shared dependencies added</returns>
        public static IServiceCollection RegisterStudentAPIServices(this IServiceCollection services)
    {
            /*
             * https://github.com/khellang/Scrutor
             * Scrutor uses the built-in .NET Code DI container to register
             * concrete classes by scanning the assemblies of type IScopedService
             * https://andrewlock.net/using-scrutor-to-automatically-register-your-services-with-the-asp-net-core-di-container/
             */
            services.Scan(scan => scan
         .FromAssemblyOf<IScopedService>()
         .AddClasses()
         .AsImplementedInterfaces()
         .WithScopedLifetime());
        return services;
    }
}
}
