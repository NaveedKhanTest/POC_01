﻿using Newtonsoft.Json;
using POC.Domain.JsonConverters;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public class BlogsPostInput : BlogsBaseData
    {
        public bool? IsDeleted { get; set; }

        [JsonConverter(typeof(CustomDateTimeConverter))]
        [DataType(DataType.Date)]
        public DateTime? CreateDateTime { get; set; }

        //public string CreatedBy { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime? UpdatedDateTime { get; set; }

    }
}
