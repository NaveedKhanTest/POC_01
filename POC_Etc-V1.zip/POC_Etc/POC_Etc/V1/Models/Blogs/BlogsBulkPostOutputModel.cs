﻿using POC_Etc.API.V1.Models.Bulk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public class BlogsBulkPostOutputModel : BulkDataOutputItem<BlogsPostOutputModel>
    {
    }
}