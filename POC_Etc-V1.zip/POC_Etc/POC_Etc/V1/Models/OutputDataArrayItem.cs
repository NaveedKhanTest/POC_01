﻿namespace POC_Etc.API.V1.Models
{
    using Newtonsoft.Json;

    /// <summary>
    /// OutputData
    /// </summary>
    /// <typeparam name="TModel">output model for bulk post</typeparam>
    public class OutputDataArrayItem<TModel>
        where TModel : new()
    {
        /// <summary>
        /// Get or set the correlation_id.
        /// </summary>
        [JsonProperty(PropertyName = "correlation_id", Order = 1)]
        public string CorrelationId { get; set; }

        /// <summary>
        /// Get or set the objects array for bulk post etc.
        /// </summary>
        [JsonProperty(PropertyName = "data", Order = 3)]
        public TModel Data { get; set; } = new TModel();
    }
}