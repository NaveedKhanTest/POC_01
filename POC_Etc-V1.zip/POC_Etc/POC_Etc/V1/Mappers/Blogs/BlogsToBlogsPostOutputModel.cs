﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public static class BlogsToBlogsPostOutputModel
    {
        public static BlogsPostOutputModel AsBlogsPostOutputModel(this POC.Data.Models.Blogs source)
        {
            source = source ?? throw new ArgumentNullException(nameof(source));

            var model = new BlogsPostOutputModel()
            {
                BlogsId = source.BlogsId,
            };

            return model;
        }


    }
}
