﻿namespace POC_Etc.API.V1.Models.Blogs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using POC.Data.Models;

    public static class BlogsToBlogsGetModel
    {
        public static BlogsGetModel AsBlogsGetModel(this POC.Data.Models.Blogs source)
        {
            source = source ?? throw new ArgumentNullException(nameof(source));

            return new BlogsGetModel()
            {
                BlogsId = source.BlogsId,
                Url = source.Url,
                IsDeleted = source.IsDeleted,
                CreatedBy = source.CreatedBy,
                CreateDateTime = source.CreateDateTime,
            };
        }        
    }
}
