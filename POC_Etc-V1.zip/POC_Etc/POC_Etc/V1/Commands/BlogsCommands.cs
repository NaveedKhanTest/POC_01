﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POC.Domain.Repositories;
using POC_Etc.API.Core;
using POC_Etc.API.Core.Models;
using POC_Etc.API.Core.Models.Messages;
using POC_Etc.API.V1.Models.Blogs;

namespace POC_Etc.API.V1.Commands
{
    public class BlogsCommands : IBlogsCommands
    {
        public BlogsCommands(IBlogsRepository blogsRepository)
        {
            this.BlogsRepository = blogsRepository ?? throw new ArgumentNullException(nameof(blogsRepository));
        }

        protected virtual IBlogsRepository BlogsRepository { get; set; }

        public async Task<List<BlogsBulkPostOutputModel>> BulkCreate(List<BlogsBulkPostInput> input)
        {
            return await BulkCreateParallelDelegate.Invoke<BlogsBulkPostInput, BlogsBulkPostOutputModel, BlogsPostInput, BlogsPostOutputModel>(input, this.Create);
            //return await BulkCreateParallelDelegate.Invoke<BlogsBulkPostInput, BlogsBulkPostOutputModel, BlogsPostInput, BlogsPostOutputModel>(input, this.Create, this.MessageHelper);
        }



        public async Task<CommandResult<BlogsPostOutputModel>> Create(BlogsPostInput unitEnrolmentsPostInput)
        {
            var errorWarningMessagesList = new List<MessageModel>();

            //Todo: validations
            //if (any validations errors)
            //{
            //    return CommandResult<BlogsPostOutputModel>.Failure(errorWarningMessagesList);
            //}

            var domainEntity = unitEnrolmentsPostInput.AsBlogs();
            var result = await BlogsRepository.Create(domainEntity);
            var resultValue = result.AsBlogsPostOutputModel();
            return CommandResult<BlogsPostOutputModel>.Success(resultValue, errorWarningMessagesList);
        }
    }
}
