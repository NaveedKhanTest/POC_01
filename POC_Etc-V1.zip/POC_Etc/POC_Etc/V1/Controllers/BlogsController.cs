﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using POC.Data.Models;
using POC.Domain.Repositories;
using POC_Etc.API.Core;
using POC_Etc.API.Core.CustomFilters;
using POC_Etc.API.Core.Models;
using POC_Etc.API.Core.Models.Messages;
using POC_Etc.API.V1.Commands;
using POC_Etc.API.V1.Models.Blogs;
using POC_Etc.API.V1.Queries;

namespace POC_Etc.API.V1.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/blogs")]
    //[ApiVersion("1.0")]
    //[Produces("application/json")]
    [ApiController]
    [TypeFilter(typeof(DenyAccessForUserTypesFilter), Arguments = new object[] { new[] { "UserType1", "Guest" } })]

    public class BlogsController : BaseController
    {

        public BlogsController(IBlogsQueries blogsQueries , IBlogsCommands blogsCommands)
        {
            BlogsCommands = blogsCommands ?? throw new ArgumentNullException(nameof(blogsCommands));
            BlogsQueries = blogsQueries ?? throw new ArgumentNullException(nameof(blogsQueries));
            //BlogsQueries = new BlogsQueries(new BlogsRepository(new BloggingDbContext()));
        }

        protected IBlogsQueries BlogsQueries { get; }

        protected IBlogsCommands BlogsCommands { get; set; }


        //[HttpGet(Name = nameof(GetAllBlogs))]
        //[ProducesResponseType(typeof(List<BlogsGetAllModel>), 200)]
        //[ProducesResponseType(typeof(MessageValuesModel), 400)]
        //[ProducesResponseType(typeof(MessageValuesModel), 500)]
        [SupportsPagedResults]
        [HttpGet(Name = nameof(GetAllBlogs))]
        public async Task<IActionResult> GetAllBlogs()
        {
            var resultList = await this.BlogsQueries.GetAllBlogs();

            if (resultList != null)
            {
                foreach (var item in resultList)
                {
                    item.Links = new[]
                    {
                        Link.Self(Url.Link(nameof(GetBlogsById), new { id = item.BlogsId }))
                    };
                }
            }

            return this.Ok(resultList);
        }


        [HttpGet("{id}", Name = nameof(GetBlogsById))]
        public async Task<IActionResult> GetBlogsById(int id)
        {
            var model = await this.BlogsQueries.GetBlogsById(id);
            if (model != null)
            {
                var selfUrl = Url.Link(nameof(GetBlogsById), new { id = model.BlogsId });
                model.Links = new[] { Link.Self(selfUrl), };


                return this.Ok(model);
            }

            return this.NotFound();
        }


        [HttpPost(Name = nameof(PostBlogs))]
        public async Task<IActionResult> PostBlogs([FromBody] BlogsPostInput input)
        {
            var result = await this.BlogsCommands.Create(input);
            if (result.ResultStatus == CommandStatus.Success)
            {
                var model = result.ResultValue;
                var selfUrl = Url.Link(nameof(GetBlogsById), new { id = model.BlogsId });
                model.Links = new[] { Link.Self(selfUrl), };
                return this.Ok(model);
            }

            return this.BadRequest(result.ResultValue);
        }


        [HttpPost("bulk", Name = nameof(PostBlogsBulk))]
        //[SwaggerOperation(OperationId = "postBlogsBulk")]
        [ProducesResponseType(typeof(List<BlogsBulkPostOutputModel>), 207)]
        [ProducesResponseType(typeof(MessageValuesModel), 400)]
        [ProducesResponseType(typeof(MessageValuesModel), 500)]
        public async Task<IActionResult> PostBlogsBulk([FromBody] List<BlogsBulkPostInput> inputList)
        {
            var resultList = await this.BlogsCommands.BulkCreate(inputList);

            if (resultList?.Any() == true)
            {
                foreach (var result in resultList)
                {
                    if (result.StatusCode == (int)HttpStatusCode.OK)
                    {
                        var selfUrl = Url.Link(nameof(GetBlogsById), new { uid = result.Data.BlogsId});
                        result.Data.Links = new[] { Link.Self(selfUrl) };

                        //if (result.Data.childrens?.Any() == true)
                        //{
                        //    foreach (var item in result.Data.childrens)
                        //    {
                        //        var childUrl = Url.Link(nameof(childController.GetChildById), new { id = item.Data.id });
                        //        item.Data.Links = new[] { Link.Self(childUrl) };
                        //    }
                        //}
                    }
                }
            }

            return StatusCode((int)HttpStatusCode.MultiStatus, resultList);
        }




    }
}