﻿namespace POC_Etc.API
{
    using System.Net;

    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.HttpOverrides;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.ApiExplorer;
    using Microsoft.AspNetCore.Mvc.Versioning;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Morcatko.AspNetCore.JsonMergePatch;
    using Newtonsoft.Json;
    using POC.Data.Models;
    using POC.Domain;
    using POC.Domain.JsonConverters;
    using POC.Domain.Repositories;
    using POC_Etc.API.Core;
    using POC_Etc.API.Core.CustomFilters;
    using POC_Etc.API.Core.SwashbuckleFilters;
    using POC_Etc.API.V1.Commands;
    using POC_Etc.API.V1.Queries;
    using Swashbuckle.AspNetCore.Swagger;

    public class Startup_bk
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">The configuration</param>
        /// <param name="env">Hosting Environment</param>
        public Startup_bk(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            HostingEnvironment = env;
        }

        /// <summary>
        /// Get the HostingEnvironment.
        /// </summary>
        public IHostingEnvironment HostingEnvironment { get; }

        /// <summary>
        /// Get the configuration.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services
                 .AddMvcCore(options =>
                 {
                     options.Filters.Add(typeof(PatchDocumentEmptyToNullConverter));
                     options.Filters.Add(typeof(ValidateModelAttribute));
                 })
                 .AddJsonOptions(options =>
                 {
                     options.SerializerSettings.ContractResolver = new EmptyCollectionContractResolver();
                     options.SerializerSettings.Formatting = Formatting.Indented;
                     options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                     options.SerializerSettings.Converters.Add(new EmptyStringToNullJsonConverter());
                     options.SerializerSettings.Converters.Add(new LongJsonConverter());
                 });
            services.AddMvc().AddJsonMergePatch();

            // support for x-forwared-proto, x-forwarded-host, x-forwarded-for (ip) so we dont have to rewrite content at the proxy.
            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.All;
                options.KnownNetworks.Add(new IPNetwork(IPAddress.Parse("0.0.0.0"), 1));
                options.KnownNetworks.Add(new IPNetwork(IPAddress.Parse("128.0.0.0"), 1));
            });

            // DI configurations
            services.AddScoped<IBlogsRepository, BlogsRepository>();
            services.AddScoped<IBlogsQueries, BlogsQueries>();
            services.AddScoped<IBlogsCommands, BlogsCommands>();
            services.AddScoped<IRequestContext, RequestContextAccessor>();

            //services.AddLazyCache();

            services.AddDbContext<BloggingDbContext>(options => options.UseSqlServer(this.Configuration.GetConnectionString("My")));
            //services.AddDbContext<MyDBSystemActivityContext>(options => options.UseSqlServer(this.Configuration.GetConnectionString("My")));

            // The group name format is the format string that is applied to the current API version being explored
            // https://github.com/Microsoft/aspnet-api-versioning/wiki/Version-Format#custom-api-version-format-strings
            services.AddVersionedApiExplorer(o => o.GroupNameFormat = "'v'VV");

            // register swagger generator
            services.AddSwaggerGen(c =>
            {
                c.OperationFilter<JsonMergePatchDocumentOperationFilter>();
                var provider = services.BuildServiceProvider()
                                       .GetRequiredService<IApiVersionDescriptionProvider>();

                foreach (var description in provider.ApiVersionDescriptions)
                {
                    c.SwaggerDoc(description.GroupName, new Info() { Title = $"My Enrolments API", Version = description.GroupName, });
                }

                c.EnableAnnotations();
                c.DescribeAllParametersInCamelCase();
                c.SchemaFilter<DatePatternSchemaFilter>();
                c.DocumentFilter<RemoveApiVersionHeaderDocumentFilter>();
                c.OperationFilter<AddResponseHeadersFilter>();
                c.OperationFilter<AddCommonHttpRequestHeaders>();
            });

            services.AddApiVersioning(o =>
            {
                // UseApiBehavior option determines whether API behaviors should be observed to filter API controllers.
                // API versioning is meant for APIs so there is a common desire to filter versioning to API-specific controllers.
                // When the value is false, no filtering occurs and all controllers are versioned
                o.UseApiBehavior = false;
                o.ReportApiVersions = true;
                o.AssumeDefaultVersionWhenUnspecified = true;
                o.DefaultApiVersion = new ApiVersion(1, 0);
                o.ApiVersionReader = ApiVersionReader.Combine(new HeaderApiVersionReader(HeaderConstant.ApiVersion), new QueryStringApiVersionReader());
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">The application builder.</param>
        /// <param name="env">The hosting environment.</param>
        /// <param name="apiVersionDescriptionProvider">apiVersionDescriptionProvider</param>
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            app.ConfigureApplicationBuilder(apiVersionDescriptionProvider);
        }
    }
}
