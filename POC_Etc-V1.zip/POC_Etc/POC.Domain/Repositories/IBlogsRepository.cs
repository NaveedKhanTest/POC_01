﻿using POC.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POC.Domain.Repositories
{
    public interface IBlogsRepository
    {
        Task<Blogs> GetBlogsById(long id, Func<IQueryable<Blogs>, IQueryable<Blogs>> queryBuilder = null);

        Task<List<Blogs>> GetAllBlogss();

        Task<Blogs> Create(Blogs blogs);

    }
}
