﻿namespace POC.Domain.JsonConverters
{
    using System;
    using System.Globalization;
    using Newtonsoft.Json;

    /// <summary>
    /// Prevents decimal to long serialisation
    /// </summary>
    public class LongJsonConverter : JsonConverter
    {
        /// <inheritdoc/>
        public override bool CanRead => true;

        /// <inheritdoc/>
        public override bool CanWrite => false;

        /// <inheritdoc/>
        public override bool CanConvert(Type objectType)
        {
            return typeof(long) == objectType || typeof(long?) == objectType;
        }

        /// <inheritdoc/>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (typeof(long) == objectType || typeof(long?) == objectType)
            {
                if (reader.Value != null)
                {
                    // try parsing the input as long using NumberStyles.Integer, this will stop any decimals
                    if (!long.TryParse(reader.Value.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out long outValue))
                    {
                        // return any string value, model state will catch and return invalid model state error
                        return "invalid";
                    }
                }
            }

            return reader.Value;
        }

        /// <inheritdoc/>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException("Unnecessary because CanWrite is false. The type will skip the converter.");
        }
    }
}