﻿using System;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace POC.Domain.JsonConverters
{
    /// <summary>
    /// CustomDateTimeConverter used to convert input to required format.
    /// Also checks that incoming date falls within SQL date range limits.
    /// </summary>
    public class CustomDateTimeConverter : IsoDateTimeConverter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomDateTimeConverter"/> class.
        /// </summary>
        public CustomDateTimeConverter()
        {
            this.DateTimeFormat = "yyyy-MM-dd";
        }

        /// <inheritdoc/>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            try
            {
                // ignore null or whitespace
                if (reader.Value == null || string.IsNullOrWhiteSpace(reader.Value.ToString()))
                {
                    return null;
                }

                // enforce yyyy-MM-dd for date
                if (!Regex.IsMatch(reader.Value.ToString(), @"^\d{4}-\d{2}-\d{2}$"))
                {
                    return "invalid date";
                }

                // call the base ReadJson method, incase of any invalid dates this will throw an exception
                var date = base.ReadJson(reader, objectType, existingValue, serializer);

                if (date != null)
                {
                    var d = Convert.ToDateTime(date);

                    if (d < SqlDateTime.MinValue || d > SqlDateTime.MaxValue)
                    {
                        return "invalid date";
                    }
                }

                return date;
            }
            catch
            {
                // return a dummy value and model state validation will trigger an error
                return "invalid date";
            }
        }

        /// <inheritdoc/>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                return;
            }

            writer.WriteValue(((DateTime)value).FormattedDateString());
        }
    }
}