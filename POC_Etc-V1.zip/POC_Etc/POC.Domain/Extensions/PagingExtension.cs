﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.Domain
{
    public static class PagingExtension
    {
        /// <summary>
        /// Converts IQueryable domain response to PagedResult
        /// </summary>
        /// <typeparam name="T">domain entity</typeparam>
        /// <param name="source">source</param>
        /// <param name="requestContext">requestContext</param>
        /// <returns>PagedResult</returns>
        public static IQueryable<T> AsPagedResult<T>(this IQueryable<T> source, IRequestContext requestContext)
            where T : class
        {

            // only PageSize and RequestedPage/page number are important


            var pagingInfo = requestContext.PagingInfo;

            if (pagingInfo == null)
            {
                pagingInfo = new PagingInfo("1", "10", 10);
                //pagingInfo.RequestedPageSize = "1";
            }

            if (pagingInfo != null && pagingInfo.PagedResultsIsEnabled)
            {
                var totalCount = source.Count();
                var pageNumLocal = 1;
                var pageSizeLocal = pagingInfo.DefaultPageSize.Value;

                if (pagingInfo.RequestedPageSize != null)
                {
                    int.TryParse(pagingInfo.RequestedPageSize, out pageSizeLocal);

                    if (pageSizeLocal == 0)
                    {
                        pageSizeLocal = pagingInfo.DefaultPageSize.Value;
                    }
                }

                if (pagingInfo.RequestedPage != null)
                {
                    int.TryParse(pagingInfo.RequestedPage, out pageNumLocal);

                    if (pageNumLocal == 0)
                    {
                        pageNumLocal = 1;
                    }
                }
                else
                {
                    // if pagenumber is null then set the pageNumber = 1 and set the pageSize to totalCount
                    // we need to return all data
                    pageSizeLocal = totalCount;
                    pageNumLocal = 1;
                }

                //// populate pagingInfo in request context so that response headers can be set
                //requestContext.PagingInfo.TotalCount = totalCount;
                //requestContext.PagingInfo.PageNumber = pageNumLocal;
                //requestContext.PagingInfo.PageSize = pageSizeLocal;

                var result = source
                            .Skip(pageSizeLocal * (pageNumLocal - 1))
                            .Take(pageSizeLocal);

                return result;
            }

            return source;
        }
    }
}
