﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.Domain
{
    public class PagingInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PagingInfo"/> class.
        /// </summary>
        /// <param name="pageFromRequestHeader">page number from Request Header</param>
        /// <param name="pageSizeFromRequestHeader">pageSize from Request Header</param>
        /// <param name="defaultPageSize">defaultPageSize</param>
        public PagingInfo(string pageFromRequestHeader, string pageSizeFromRequestHeader, int? defaultPageSize)
        {
            this.RequestedPage = pageFromRequestHeader;
            this.RequestedPageSize = pageSizeFromRequestHeader;
            this.DefaultPageSize = defaultPageSize;
        }

        /// <summary>
        /// Requested Page from Request Header
        /// </summary>
        public string RequestedPage { get; }

        /// <summary>
        /// Requested PageSize from Request Header
        /// page size as an integer value
        /// </summary>
        public string RequestedPageSize { get; set; }

        /// <summary>
        /// DefaultPageSize
        /// </summary>
        public int? DefaultPageSize { get; set; } = 10;

        /// <summary>
        /// If Request Header contains Page header then paged results is enabled
        /// </summary>
        public bool PagedResultsIsEnabled => !string.IsNullOrEmpty(this.RequestedPage);

        /// <summary>
        /// Total items count
        /// </summary>
        [JsonProperty(PropertyName = "totalCount", Order = 1)]
        public int TotalCount { get; set; }

        /// <summary>
        /// PageNumber
        /// </summary>
        [JsonProperty(PropertyName = "pageNumber", Order = 2)]
        public int PageNumber { get; set; }

        /// <summary>
        /// PageSize
        /// </summary>
        [JsonProperty(PropertyName = "pageSize", Order = 3)]
        public int PageSize { get; set; }

        /// <summary>
        /// TotalPages
        /// </summary>
        [JsonProperty(PropertyName = "totalPages", Order = 4)]
        public int TotalPages => (int)Math.Ceiling(this.TotalCount / (double)this.PageSize);

        /// <summary>
        /// HasPreviousPage
        /// </summary>
        [JsonIgnore]
        public bool HasPreviousPage => this.PageNumber > 1 && this.PageNumber - 1 <= this.TotalPages;

        /// <summary>
        /// HasNextPage
        /// </summary>
        [JsonIgnore]
        public bool HasNextPage => this.PageNumber < this.TotalPages;

        /// <summary>
        /// NextPageNumber
        /// </summary>
        [JsonIgnore]
        public int NextPageNumber => this.HasNextPage ? this.PageNumber + 1 : this.TotalPages;

        /// <summary>
        /// PreviousPageNumber
        /// </summary>
        [JsonIgnore]
        public int PreviousPageNumber => this.HasPreviousPage ? this.PageNumber - 1 : 1;
    }
}
