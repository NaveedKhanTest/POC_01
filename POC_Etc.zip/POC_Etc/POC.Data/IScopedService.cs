﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.Data
{
    /// <summary>
    /// Interface used by Scrutor for Assembly Scanning and Registering
    /// Concrete classes that needs to be registered in DI container
    /// must impement this IScopedService interface
    /// </summary>
    internal interface IScopedService
    {
    }
}
