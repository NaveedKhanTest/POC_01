﻿using System;
using System.Collections.Generic;

namespace POC.Data.Models
{
    public partial class Blogs
    {
        public Blogs()
        {
            Posts = new HashSet<Posts>();
        }

        public int BlogsId { get; set; }
        public string Url { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public virtual ICollection<Posts> Posts { get; set; }
    }
}
