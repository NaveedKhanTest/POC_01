﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace POC.Data.Models
{
    public partial class BloggingDbContext : DbContext //, IScopedService
    {
        public BloggingDbContext()
        {
        }

        public BloggingDbContext(DbContextOptions<BloggingDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Authors> Authors { get; set; }
        public virtual DbSet<Blogs> Blogs { get; set; }
        public virtual DbSet<Posts> Posts { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.;Database=BloggingDb;Trusted_Connection=True;");
            }
        }

        // renamed OnModelCreating to OnModelCreatingInternal
        protected  void  OnModelCreatingInternal(ModelBuilder modelBuilder)
        //protected override void  OnModelCreating(ModelBuilder modelBuilder)
        {

            //modelBuilder.Entity<Blog>().Property<string>("TenantId").HasField("_tenantId");

            //// Configure entity filters
            //modelBuilder.Entity<Blogs>().HasQueryFilter(b => EF.Property<string>(b, "TenantId") == _tenantId);
            //modelBuilder.Entity<Blogs>().HasQueryFilter(b => !b.IsDeleted?.Value);
            //modelBuilder.Entity<Posts>().HasQueryFilter(p => !p.IsDeleted);

            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<Authors>(entity =>
            {
                entity.Property(e => e.AuthorsName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<Blogs>(entity =>
            {
                entity.Property(e => e.CreateDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Url).IsRequired();
            });

            modelBuilder.Entity<Posts>(entity =>
            {
                entity.Property(e => e.CreateDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.HasOne(d => d.Authors)
                    .WithMany(p => p.Posts)
                    .HasForeignKey(d => d.AuthorsId);

                entity.HasOne(d => d.Blogs)
                    .WithMany(p => p.Posts)
                    .HasForeignKey(d => d.BlogsId);
            });
        }
    }
}
