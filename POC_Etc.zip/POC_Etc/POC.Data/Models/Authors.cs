﻿using System;
using System.Collections.Generic;

namespace POC.Data.Models
{
    public partial class Authors
    {
        public Authors()
        {
            Posts = new HashSet<Posts>();
        }

        public int AuthorsId { get; set; }
        public string AuthorsName { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public virtual ICollection<Posts> Posts { get; set; }
    }
}
