﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System
{
    /// <summary>
    /// DateTimeExtensions
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Returns the date before the date passed in, time componenet is ignored
        /// If null datetime is passed, current date -1 is returned
        /// </summary>
        /// <param name="datetime">input date</param>
        /// <returns>returns the day before the passed in date</returns>
        public static DateTime? GetDayBefore(this DateTime? datetime)
        {
            return datetime.GetValueOrDefault(ApplicationTime.Now).GetDayBefore();
        }

        /// <summary>
        /// Returns the date before the date passed in, time componenet is ignored
        /// </summary>
        /// <param name="datetime">input date</param>
        /// <returns>returns the day before the passed in date</returns>
        public static DateTime GetDayBefore(this DateTime datetime)
        {
            return datetime.Date.AddDays(-1);
        }

        /// <summary>
        /// Returns date string in yyyy-MM-dd format
        /// </summary>
        /// <param name="datetime">input</param>
        /// <returns>date string in yyyy-MM-dd format</returns>
        public static string FormattedDateString(this DateTime datetime)
        {
            return datetime.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// Returns date string in yyyy-MM-dd format
        /// </summary>
        /// <param name="datetime">input</param>
        /// <returns>date string in yyyy-MM-dd format</returns>
        public static string FormattedDateString(this DateTime? datetime)
        {
            return datetime?.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// Checks if date is greater than or equal to AEST today
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <returns>true if the date is greater than or equal to AEST today or otherwise false</returns>
        public static bool IsTodayOrFuture(this DateTime dateTime)
        {
            return dateTime >= ApplicationTime.Now;
        }

        /// <summary>
        /// Checks if date is greater than or equal to AEST today
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <returns>true if the date is greater than or equal to AEST today or otherwise false</returns>
        public static bool IsNullOrTodayOrFuture(this DateTime? dateTime)
        {
            if (dateTime.HasValue)
            {
                return dateTime >= ApplicationTime.Now;
            }

            return true;
        }

        /// <summary>
        /// Checks if date is greater than AEST today
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <returns>true if the date is greater than AEST today or otherwise false</returns>
        public static bool IsFuture(this DateTime dateTime)
        {
            return dateTime > ApplicationTime.Now;
        }

        /// <summary>
        /// Checks if date is greater than AEST today
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <returns>true if the date is greater than AEST today or otherwise false</returns>
        public static bool IsNullOrFuture(this DateTime? dateTime)
        {
            if (dateTime.HasValue)
            {
                return dateTime > ApplicationTime.Now;
            }

            return true;
        }

        /// <summary>
        /// Converts UTC time to AEST date, time component is ignored
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <returns>AEST date</returns>
        public static DateTime AsAEST(this DateTime dateTime)
        {
            var aest = TimeZoneInfo.FindSystemTimeZoneById("AUS Eastern Standard Time");
            var utcDateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
            return TimeZoneInfo.ConvertTime(utcDateTime, aest).Date;
        }

        /// <summary>
        /// Return true if this dateTime is On or Before dateTime2 or is Null
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <param name="dateTime2">input datetime2</param>
        /// <returns>true or false</returns>
        public static bool IsNullOrOnOrBeforeDate2(this DateTime? dateTime, DateTime? dateTime2)
        {
            if (dateTime.HasValue && dateTime2.HasValue)
            {
                return dateTime <= dateTime2;
            }

            return true;
        }

        /// <summary>
        /// Return true if this dateTime is On or Before dateTime2
        /// </summary>
        /// <param name="dateTime">input datetime</param>
        /// <param name="dateTime2">input datetime2</param>
        /// <returns>true or false</returns>
        public static bool IsOnOrBeforeDate2(this DateTime dateTime, DateTime? dateTime2)
        {
            if (dateTime2.HasValue)
            {
                return dateTime <= dateTime2;
            }

            return true;
        }
    }
}