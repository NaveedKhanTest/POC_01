﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System
{
    /// <summary>
    /// ApplicationTime
    /// </summary>
    public struct ApplicationTime
    {
        /// <summary>
        /// Return current AEST datetime stripping the time component
        /// </summary>
        /// <returns>current AEST datetime stripping the time component</returns>
        public static DateTime Now
        {
            get
            {
                var aest = TimeZoneInfo.FindSystemTimeZoneById("AUS Eastern Standard Time");
                return TimeZoneInfo.ConvertTime(DateTime.UtcNow, aest).Date;
            }
        }
    }
}
