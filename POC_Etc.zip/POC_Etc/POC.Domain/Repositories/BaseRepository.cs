﻿using POC.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace POC.Domain.Repositories
{

    // IScopedService => https://andrewlock.net/using-scrutor-to-automatically-register-your-services-with-the-asp-net-core-di-container/
    public abstract class BaseRepository //: IScopedService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="dbContext">The dbContext</param>
        /// <param name="requestContext">requestContext accessor</param>
        public BaseRepository(BloggingDbContext dbContext, IRequestContext requestContext)
        {
            this.DbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            this.RequestContextAccessor = requestContext ?? throw new ArgumentNullException(nameof(requestContext));

        }

        /// <summary>
        /// The DB Context.
        /// </summary>
        protected virtual BloggingDbContext DbContext { get; set; }
        protected virtual IRequestContext RequestContextAccessor { get; set; }



    }
}
