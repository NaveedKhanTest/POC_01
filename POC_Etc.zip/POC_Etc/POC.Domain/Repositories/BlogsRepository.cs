﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POC.Data.Models;

namespace POC.Domain.Repositories
{
    public class BlogsRepository : BaseRepository, IBlogsRepository//, IScopedService
    {
        // BloggingDbContext

        public BlogsRepository(BloggingDbContext dbContext, IRequestContext requestContext)
: base(dbContext, requestContext)
        {
        }

        public async Task<Blogs> Create(Blogs blogs)
        {
            var result = await DbContext.Blogs.AddAsync(blogs);
            DbContext.SaveChanges();
            return result.Entity;
        }

        public async Task<List<Blogs>> GetAllBlogss()
        {
            return await DbContext.Blogs.OrderBy(x => x.BlogsId).AsPagedResult(RequestContextAccessor).ToListAsync();
        }

        public async Task<Blogs> GetBlogsById(long id, Func<IQueryable<Blogs>, IQueryable<Blogs>> queryBuilder = null)
        {
            IQueryable<Blogs> query = DbContext.Blogs;

            if (queryBuilder != null)
            {
                query = queryBuilder.Invoke(query);
            }

            return await query
               //.Include(s => s.Posts)
               //.ThenInclude(x => x..PostsChild)               
               .SingleOrDefaultAsync(x => x.BlogsId == id);

            //return await DbContext.Blogs
            //   //.Include(s => s.Posts)
            //   //.ThenInclude(x => x..PostsChild)               
            //   .SingleOrDefaultAsync(x => x.BlogsId == id);
        }
    }
}
