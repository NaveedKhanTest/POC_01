﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.Domain
{
    public interface IRequestContext
    {

        /// <summary>
        /// user-name in request header
        /// </summary>
        string UserName { get; set; }

        /// <summary>
        /// message-id in request header
        /// </summary>
        string MessageId { get; set; }

        /// <summary>
        /// Method - POST/PATCH/DELETE
        /// </summary>
        string Method { get; set; }

        string UserType { get; set; }

        /// <summary>
        /// transactionTimestamp
        /// </summary>
        DateTime? ClientTransactionTimestamp { get; set; }



        /// <summary>
        /// Contains PagingInfo
        /// </summary>
        PagingInfo PagingInfo { get; set; }
    }
}
