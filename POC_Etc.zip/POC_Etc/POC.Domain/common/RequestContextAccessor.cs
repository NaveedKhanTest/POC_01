﻿using POC.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.Domain
{
    public sealed class RequestContextAccessor : IRequestContext //, IScopedService
    {
        private string username;

        /// <summary>
        /// organisation-id in request header
        /// </summary>
        public string ProviderCode { get; set; }

        /// <summary>
        /// Provider Res Key for Provider Code
        /// </summary>
        public long ProviderUid { get; set; }

        /// <summary>
        /// provider-type in request header
        /// </summary>
        public string ProviderType { get; set; }

        /// <summary>
        /// user-name in request header
        /// </summary>
        public string UserName
        {
            get
            {
                return username ?? HeaderConstant.DefaultUserName;
            }

            set
            {
                username = value;
            }
        }

        /// <summary>
        /// message-id in request header
        /// </summary>
        public string MessageId { get; set; }

        /// <inheritdoc/>
        public string Method { get; set; }

        /// <inheritdoc/>
        public DateTime? DhstransactionTimestamp { get; set; }

        /// <inheritdoc/>
        public DateTime? ProviderTimestamp { get; set; }


        public DateTime? ClientTransactionTimestamp { get; set; }
        public PagingInfo PagingInfo { get; set; } = null;
        public string UserType { get; set; } = "TempUserType";
        //public PagingInfo PagingInfo { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        //public PagingInfo { get; set; } = null;

    }
}
