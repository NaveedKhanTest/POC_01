﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.Domain
{
    /// <summary>
    /// Interface used by Scrutor for Assembly Scanning and Registering
    /// Concrete classes that needs to be registered in DI container
    /// must impement this IScopedService interface
    /// </summary>
    internal interface IScopedService
    {
    }
}
