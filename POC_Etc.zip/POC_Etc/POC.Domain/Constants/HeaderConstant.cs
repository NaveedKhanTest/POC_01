﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.Domain
{
    public static class HeaderConstant
    {
        /// <summary>
        /// PaginationPage in response header
        /// </summary>
        public const string PaginationRequestedPage = "My-Pagination-RequestedPage";

        /// <summary>
        /// PaginationPage in response header
        /// </summary>
        public const string PaginationRequestedPageSize = "My-Pagination-RequestedPageSize";

        /// <summary>
        /// PaginationPage in response header
        /// </summary>
        public const string PaginationPage = "My-Pagination-Page";

        /// <summary>
        /// PaginationPageSize in response header
        /// </summary>
        public const string PaginationPageSize = "H-Pagination-PageSize";

        /// <summary>
        /// PaginationRecordCount in response header
        /// </summary>
        public const string PaginationRecordCount = "My-Pagination-RecordCount";

        /// <summary>
        /// PaginationPageCount in response header
        /// </summary>
        public const string PaginationPageCount = "My-Pagination-PageCount";

        /// <summary>
        /// PaginationPreviousPage in response header
        /// </summary>
        public const string PaginationPreviousPage = "My-Pagination-PreviousPage";

        /// <summary>
        /// PaginationNextPage in response header
        /// </summary>
        public const string PaginationNextPage = "My-Pagination-NextPage";

        /// <summary>
        /// organisation-id in request header
        /// </summary>
        public static readonly string ProviderCode = "organisation-id";

        /// <summary>
        /// organisation-name
        /// </summary>
        public static readonly string ProviderName = "organisation-name";

        /// <summary>
        /// user-name in request header
        /// </summary>
        public static readonly string UserName = "user-name";

        /// <summary>
        /// message-id in request header
        /// </summary>
        public static readonly string MessageId = "message-id";

        /// <summary>
        /// api-version in request header
        /// </summary>
        public static readonly string ApiVersion = "api-version";


        /// <summary>
        /// String-timestamp
        /// </summary>
        public static readonly string StringTimeStamp = "String-timestamp";

        /// <summary>
        /// API Transaction Channel
        /// </summary>
        public static readonly string APITransactionChannel = "API";


        /// <summary>
        /// GET operation
        /// </summary>
        public static readonly string GET = "GET";

        /// <summary>
        /// Default user e.g. if user-name is missing in http request header
        /// </summary>
        public static readonly string DefaultUserName = "SystemUser";
    }
}