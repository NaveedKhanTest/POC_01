﻿using System;
using Newtonsoft.Json;

namespace POC.Domain.JsonConverters
{
    /// <summary>
    /// Converts empty and blank strings to null while serialising
    /// </summary>
    public class EmptyStringToNullJsonConverter : JsonConverter
    {
        /// <inheritdoc/>
        public override bool CanRead => true;

        /// <inheritdoc/>
        public override bool CanWrite => false;

        /// <inheritdoc/>
        public override bool CanConvert(Type objectType)
        {
            return typeof(string) == objectType;
        }

        /// <inheritdoc/>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.Value == null)
            {
                return null;
            }
            else
            {
                var value = reader.Value.ToString();

                if (IsPathImmutable(reader.Path))
                {
                    return value;
                }

                // if empty or white space return null value otherwise return trimmed value
                return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
            }
        }

        /// <inheritdoc/>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException("Unnecessary because CanWrite is false. The type will skip the converter.");
        }

        private bool IsPathImmutable(string path)
        {
            // Json property correlation_id value used in bulk post are immutable, so do not remove spaces
            // correlation_id is the standard property name used for all bulk post inputs
            if (path != null)
            {
                return path.EndsWith("correlation_id");
            }

            return false;
        }
    }
}
