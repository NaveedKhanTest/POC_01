
1) Create new Sql server databse project from Visual Studio. 
2) create a new Db using SQL Server Management Studio.
3) Import db from SQL Server to Visual Studio db project

you can do changes in Sql Seerve Management Studio SSMS and generate script and copy past in the DB project in VS.

VS => New poject => SQL Server => SQL Server Database Project => Type Name BloggingDb 

Right click BloggingDb => Import => Database => Select Connection => Browse => Server Name = '.' etc

====================

Install Swashbuckle.AspNetCore


---------
SQL Server Compare Schema in Visual Studio 2017:
Select Db project in VS, I go to Tools > SQL Server > New Schema Compare.

Select source and destinaton and compare, select/unselect changes and click update. it will update the target db.

----------
Register services using assembly scanning and a fluent API.
IScopedService => https://andrewlock.net/using-scrutor-to-automatically-register-your-services-with-the-asp-net-core-di-container/
Install-Package Scrutor -Version 3.0.2

--------

Global Query Filters
https://docs.microsoft.com/en-us/ef/core/querying/filters

// need to add in BloggingDbContext every time we regenerate BloggingDbContext
//  each time you generate the model will lose that configuration.
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Blog>().Property<string>("TenantId").HasField("_tenantId");

    // Configure entity filters
    modelBuilder.Entity<Blog>().HasQueryFilter(b => EF.Property<string>(b, "TenantId") == _tenantId);
    modelBuilder.Entity<Post>().HasQueryFilter(p => !p.IsDeleted);
}

//Disabling Filters
blogs = db.Blogs.Include(b => b.Posts)
    .IgnoreQueryFilters().ToList();

//	if using partial class for DbContex, modify the generated code (change the generated OnModelCreating signatur to OnModelCreatingInternal and remove the override)
---------------

We can have saperate DBContext for Logs to log the exceptions
