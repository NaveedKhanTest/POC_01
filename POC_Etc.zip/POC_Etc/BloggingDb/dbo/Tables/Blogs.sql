﻿CREATE TABLE [dbo].[Blogs] (
    [BlogsId]         INT            IDENTITY (1, 1) NOT NULL,
    [Url]             NVARCHAR (MAX) NOT NULL,
    [IsDeleted]       BIT            NULL,
    [CreateDateTime]  DATETIME       CONSTRAINT [DF_Blogs_CreateDateTime] DEFAULT (getdate()) NULL,
    [CreatedBy]       VARCHAR (100)  NULL,
    [UpdatedBy]       VARCHAR (100)  NULL,
    [UpdatedDateTime] DATETIME       NULL,
    CONSTRAINT [PK_Blogs] PRIMARY KEY CLUSTERED ([BlogsId] ASC)
);

