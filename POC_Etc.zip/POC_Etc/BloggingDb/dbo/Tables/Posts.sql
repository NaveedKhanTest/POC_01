﻿CREATE TABLE [dbo].[Posts] (
    [PostsId]         INT            IDENTITY (1, 1) NOT NULL,
    [BlogsId]         INT            NOT NULL,
    [AuthorsId]       INT            NOT NULL,
    [Content]         NVARCHAR (MAX) NULL,
    [Title]           NVARCHAR (MAX) NULL,
    [IsDeleted]       BIT            NULL,
    [CreateDateTime]  DATETIME       CONSTRAINT [DF_Posts_CreateDateTime] DEFAULT (getdate()) NULL,
    [CreatedBy]       VARCHAR (100)  NULL,
    [UpdatedBy]       VARCHAR (100)  NULL,
    [UpdatedDateTime] DATETIME       NULL,
    CONSTRAINT [PK_Posts] PRIMARY KEY CLUSTERED ([PostsId] ASC),
    CONSTRAINT [FK_Posts_Authors_AuthorsId] FOREIGN KEY ([AuthorsId]) REFERENCES [dbo].[Authors] ([AuthorsId]) ON DELETE CASCADE,
    CONSTRAINT [FK_Posts_Blogs_BlogsId] FOREIGN KEY ([BlogsId]) REFERENCES [dbo].[Blogs] ([BlogsId]) ON DELETE CASCADE
);

