﻿CREATE TABLE [dbo].[Authors] (
    [AuthorsId]       INT           IDENTITY (1, 1) NOT NULL,
    [AuthorsName]     VARCHAR (100) NULL,
    [IsDeleted]       BIT           NULL,
    [CreateDateTime]  DATETIME      CONSTRAINT [DF_Authors_CreateDateTime] DEFAULT (getdate()) NULL,
    [CreatedBy]       VARCHAR (100) NULL,
    [UpdatedBy]       VARCHAR (100) NULL,
    [UpdatedDateTime] DATETIME      NULL,
    CONSTRAINT [PK_Authors] PRIMARY KEY CLUSTERED ([AuthorsId] ASC)
);

