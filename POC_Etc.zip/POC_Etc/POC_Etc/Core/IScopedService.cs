﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core
{
    /// <summary>
    /// Interface used by Scrutor for Assembly Scanning and Registering
    /// Concrete classes that needs to be registered in DI container
    /// must impement this IScopedService interface
    /// </summary>
    internal interface IScopedService
    {
    }
}
