﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core
{
    public abstract class BaseController : ControllerBase
    {

        ///// <summary>
        /////  Creates an Microsoft.AspNetCore.Mvc.BadRequestObjectResult that produces a Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest
        /////  response with the error messages passed in
        ///// </summary>
        ///// <param name="error">contains the messages</param>
        ///// <returns>BadRequestObjectResult object</returns>
        //protected virtual BadRequestObjectResult BadRequest(IMessages error)
        //{
        //    return this.BadRequest(new MessageValuesModel() { Messages = ((IMessages)error).Messages });
        //}
    }
}
