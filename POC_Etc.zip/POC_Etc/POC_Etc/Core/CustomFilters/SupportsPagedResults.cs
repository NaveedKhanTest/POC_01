﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using POC.Domain;
using System;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


namespace POC_Etc.API.Core.CustomFilters
{
    public class SupportsPagedResults : Attribute, IActionFilter
    {
        /// <inheritdoc/>
        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Result.GetType() == typeof(OkObjectResult))
            {
                var result = (OkObjectResult)context.Result;
                var requestContext = context.HttpContext.RequestServices.GetService<IRequestContext>();
                var pagingInfo = requestContext.PagingInfo;

                // if PagedResultsIsEnabled then set reponse headers
                if (result != null && result.Value != null && pagingInfo != null && pagingInfo.PagedResultsIsEnabled)
                {
                    context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationRequestedPage, pagingInfo.RequestedPage);

                    if (!string.IsNullOrEmpty(pagingInfo.RequestedPageSize))
                    {
                        context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationRequestedPageSize, pagingInfo.RequestedPageSize);
                    }

                    context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationPage, pagingInfo.PageNumber.ToString());
                    context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationPageSize, pagingInfo.PageSize.ToString());
                    context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationPageCount, pagingInfo.TotalPages.ToString());
                    context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationRecordCount, pagingInfo.TotalCount.ToString());

                    if (pagingInfo.HasPreviousPage)
                    {
                        context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationPreviousPage, pagingInfo.PreviousPageNumber.ToString());
                    }

                    if (pagingInfo.HasNextPage)
                    {
                        context.HttpContext.Response.Headers.Add(HeaderConstant.PaginationNextPage, pagingInfo.NextPageNumber.ToString());
                    }
                }
            }
        }

        /// <inheritdoc/>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            var page = context.HttpContext.Request.Headers.Where(h => h.Key == HeaderConstant.PaginationPage).FirstOrDefault();
            var pageSize = context.HttpContext.Request.Headers.Where(h => h.Key == HeaderConstant.PaginationPageSize).FirstOrDefault();

            // if we find HeaderConstant.PaginationPage header in the request, then the results can be paginated
            // so instantiate the PagingInfo class in request context
            if (page.Key != null)
            {
                var requestContext = context.HttpContext.RequestServices.GetService<IRequestContext>();
                var configuration = context.HttpContext.RequestServices.GetService<IConfiguration>();
                var defautltPageSize = configuration.GetValue<int?>("DefaultPageSize");

                var pageValue = page.Value;
                string pageSizeValue = null;

                if (pageSize.Key != null)
                {
                    pageSizeValue = pageSize.Value;
                }

                requestContext.PagingInfo = new PagingInfo(pageValue, pageSizeValue, defautltPageSize);
            }
        }
    }
}