﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.CustomFilters
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using POC.Domain;

    /// <summary>
    /// DenyAccessForUserTypesFilter
    /// </summary>
    public class DenyAccessForUserTypesFilter : IActionFilter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DenyAccessForUserTypesFilter"/> class.
        /// </summary>
        /// <param name="requestContext">requestContext accessor</param>
        /// <param name="providerTypes">provider type list</param>
        public DenyAccessForUserTypesFilter(IRequestContext requestContext, string[] providerTypes)
        {
            this.RequestContextAccessor = requestContext ?? throw new ArgumentNullException(nameof(requestContext));
            this.UserTypes = providerTypes ?? throw new ArgumentNullException(nameof(providerTypes));
        }

        /// <summary>
        /// Gets RequestContextAccessor
        /// </summary>
        protected IRequestContext RequestContextAccessor { get; }

        /// <summary>
        /// Gets UserTypes
        /// </summary>
        protected string[] UserTypes { get; }

        /// <inheritdoc/>
        public void OnActionExecuted(ActionExecutedContext context)
        {
        }

        /// <inheritdoc/>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (this.UserTypes != null)
            {
                if (this.UserTypes.Any(_ => _.ToLower() == this.RequestContextAccessor.UserType.ToLower()))
                {
                    context.Result = new NotFoundObjectResult(null);
                }
            }
        }
    }
}
