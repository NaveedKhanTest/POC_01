﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models.Messages
{
    public class MessageValuesModel
    {
        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        [JsonProperty(PropertyName = "messages")]
        public IList<MessageModel> Messages { get; set; }
    }
}