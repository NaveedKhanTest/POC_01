﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models.Messages
{
    public class MessageModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessageModel"/> class.
        /// </summary>
        internal MessageModel()
        {
        }

        /// <summary>
        /// Get or Set MessageId .
        /// </summary>
        [JsonProperty(PropertyName = "message_id", Order = 1)]
        public string MessageId { get; internal set; }

        /// <summary>
        /// Get or Set Description.
        /// </summary>
        [JsonProperty(PropertyName = "description", Order = 2)]
        public string Description { get; internal set; }

        /// <summary>
        /// Get or Set Severity
        /// </summary>
        [JsonProperty(PropertyName = "severity", Order = 3)]
        public string Severity { get; internal set; }
    }
}