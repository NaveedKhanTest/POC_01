﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models
{
    public class Link
    {
        /// <summary>
        /// "self" relationship.
        /// </summary>
        public const string SELF = "self";

        /// <summary>
        /// "modified" relationship.
        /// </summary>
        public const string MODIFIED = "modified";

        /// <summary>
        /// "modified" relationship.
        /// </summary>
        public const string PREVIOUS = "previousPage";

        /// <summary>
        /// "modified" relationship.
        /// </summary>
        public const string NEXT = "nextPage";

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// </summary>
        public Link()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// Constructor for LinkModel.
        /// </summary>
        /// <param name="href">href</param>
        /// <param name="rel">rel</param>
        internal Link(string href, string rel)
        {
            Href = href ?? throw new ArgumentNullException(nameof(href));
            Rel = rel ?? throw new ArgumentNullException(nameof(rel));
        }

        /// <summary>
        /// URL of related resource.
        /// </summary>
        [Description("URL")]
        [JsonProperty(PropertyName = "href", Order = 1)]
        public string Href { get; set; }

        /// <summary>
        /// Relationship with the current entity.
        /// </summary>
        [Description("Relationship with current entity")]
        [JsonProperty(PropertyName = "rel", Order = 2)]
        public string Rel { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// </summary>
        /// <param name="href">The href</param>
        /// <returns>A Link.</returns>
        public static Link Self(string href)
        {
            var link = new Link(href, SELF);
            return link;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// </summary>
        /// <param name="href">The href</param>
        /// <returns>A Link.</returns>
        public static Link Modified(string href)
        {
            var link = new Link(href, MODIFIED);
            return link;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// </summary>
        /// <param name="href">The href</param>
        /// <returns>A Link.</returns>
        public static Link Previous(string href)
        {
            var link = new Link(href, PREVIOUS);
            return link;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Link"/> class.
        /// </summary>
        /// <param name="href">The href</param>
        /// <returns>A Link.</returns>
        public static Link Next(string href)
        {
            var link = new Link(href, NEXT);
            return link;
        }
    }
}
