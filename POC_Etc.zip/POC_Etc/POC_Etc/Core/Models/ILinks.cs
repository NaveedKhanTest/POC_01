﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models
{
    public interface ILinks
    {
        IList<Link> Links { get; set; }
    }
}
