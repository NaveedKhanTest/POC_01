﻿using POC_Etc.API.Core.Models.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.Core.Models
{
    public class CommandResult<T>
        where T : IMessages, new()
    {
        private CommandResult()
        {
        }

        /// <summary>
        /// Get or sets Result Status
        /// </summary>
        public CommandStatus ResultStatus { get; private set; }

        /// <summary>
        /// Get or sets ResultValue
        /// </summary>
        public T ResultValue { get; private set; }

        /// <summary>
        /// Sets the command status to Success
        /// </summary>
        /// <param name="resultValue">result value</param>
        /// <param name="messageList">message list</param>
        /// <returns>returns command result</returns>
        public static CommandResult<T> Success(T resultValue, List<MessageModel> messageList)
        {
            var returnvalue = new CommandResult<T>
            {
                ResultValue = resultValue,
                ResultStatus = CommandStatus.Success,
            };
            returnvalue.ResultValue.Messages.AddRange(messageList);

            return returnvalue;
        }

        /// <summary>
        /// Sets the command status to Success
        /// </summary>
        /// <param name="messageList">message list</param>
        /// <returns>returns command result</returns>
        public static CommandResult<T> Success(List<MessageModel> messageList)
        {
            var returnvalue = new CommandResult<T>
            {
                ResultValue = new T(),
                ResultStatus = CommandStatus.Success,
            };
            returnvalue.ResultValue.Messages = messageList;

            return returnvalue;
        }

        /// <summary>
        /// Sets the command status to Success
        /// </summary>
        /// <param name="messageList">message list</param>
        /// <returns>returns command result</returns>
        public static CommandResult<T> Failure(List<MessageModel> messageList)
        {
            var returnvalue = new CommandResult<T>
            {
                ResultValue = new T(),
                ResultStatus = CommandStatus.Failure,
            };
            returnvalue.ResultValue.Messages = messageList;

            return returnvalue;
        }
    }
}
