﻿namespace POC_Etc.API.V1.Commands
{
    using POC_Etc.API.Core.Models;
    using POC_Etc.API.Core.Models.Output;
    using POC_Etc.API.V1.Models.Blogs;
    using System.Collections.Generic;
    using System.Threading.Tasks;


    public interface IBlogsCommands
    {
        Task<CommandResult<BlogsPostOutputModel>> Create(BlogsPostInput unitEnrolmentsPostInput);

        Task<List<BlogsBulkPostOutputModel>> BulkCreate(List<BlogsBulkPostInput> input);


        //Task<CommandResult<BlogsPatchOutputModel>> Update(BlogsDto blogsDto);

        //Task<CommandResult<ModelWithMessagesAndLinks>> Delete(BlogsDto blogsDto);

    }
}
