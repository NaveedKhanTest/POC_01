﻿using POC_Etc.API.V1.Models.Blogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Queries
{
    public interface IBlogsQueries
    {

        Task<BlogsGetModel> GetBlogsById(long uid);

        Task<List<BlogsGetAllModel>> GetAllBlogs();
    }
}
