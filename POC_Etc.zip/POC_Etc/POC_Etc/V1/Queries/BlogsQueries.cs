﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POC.Data.Models;
using POC.Domain.Repositories;
using POC_Etc.API.Core;
using POC_Etc.API.V1.Models.Blogs;

namespace POC_Etc.API.V1.Queries
{
    public class BlogsQueries : IBlogsQueries//, IScopedService
    {

        public BlogsQueries(IBlogsRepository blogsRepository)
        {
            this.BlogsRepository = blogsRepository ?? throw new ArgumentNullException(nameof(blogsRepository));
        }

        protected virtual IBlogsRepository BlogsRepository { get; set; }


        public async Task<List<BlogsGetAllModel>> GetAllBlogs()
        {
            var result = await this.BlogsRepository.GetAllBlogss();
            return result.AsBlogsGetAllModel();

        }

        public async Task<BlogsGetModel> GetBlogsById(long uid)
        {
            //Func<string, string> selector = str => str.ToUpper();

            Func<IQueryable<Blogs>, IQueryable<Blogs>> queryBuilder = q =>
            {
                var query = q.Include(x => x.Posts);
                return query;
            };

            //IQueryable<Blogs> queryBuilder(IQueryable<Blogs> q)
            //{
            //    return q.Include(x => x.Posts);
            //}

        //    var blogs = context.Blogs
        //.Include(blog => blog.Posts)
        //.Include(blog => blog.Owner)
        //.ToList();

            //For EF6 include chain:
            //.Include(p => p.PostAuthor.Select(pa => pa.Author).Select(a => a.Interests))

            //Translates to EF Core:
            //.Include(p => p.PostAuthor).ThenInclude(pa => pa.Author).ThenInclude(a => a.Interests)

            var blogsEntity = await this.BlogsRepository.GetBlogsById(uid, queryBuilder);
            if (blogsEntity != null)
            {
                // BlogsToBlogsGetModel
                return blogsEntity.AsBlogsGetModel();
            }

            return null;
        }



        //var result = await DbContext.UnitEnrolments.AddAsync(unitEnrolments);
        //DbContext.SaveChanges();
        //    return result.Entity;

    }
}
