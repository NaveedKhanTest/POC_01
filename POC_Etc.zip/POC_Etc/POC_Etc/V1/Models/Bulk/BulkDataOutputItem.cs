﻿namespace POC_Etc.API.V1.Models.Bulk
{
    using Newtonsoft.Json;

    /// <summary>
    /// bulk post Data Result
    /// </summary>
    /// <typeparam name="TModel">output model for bulk post</typeparam>
    public class BulkDataOutputItem<TModel> : OutputDataArrayItem<TModel>
        where TModel : new()
    {
        /// <summary>
        /// Get or set the status_code.
        /// </summary>
        [JsonProperty(PropertyName = "status_code", Order = 2)]
        public int StatusCode { get; set; }

        /// <summary>
        /// Item Position
        /// </summary>
        [JsonIgnore]
        public long Position { get; set; }
    }
}
