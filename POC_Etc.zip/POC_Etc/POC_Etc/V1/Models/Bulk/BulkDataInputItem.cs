﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Bulk
{
    /// <summary>
    /// input data for bulk post
    /// </summary>
    /// <typeparam name="TModel">input model for bulk post</typeparam>
    public class BulkDataInputItem<TModel>
        where TModel : class
    {
        /// <summary>
        /// Get or set the correlation_id.
        /// </summary>
        [JsonProperty(PropertyName = "correlation_id", Order = 1)]
        [Required]
        public string CorrelationId { get; set; }

        /// <summary>
        /// Get or set the objects array for bulk post etc.
        /// </summary>
        [JsonProperty(PropertyName = "data", Order = 2)]
        [Required]
        public TModel Data { get; set; }
    }
}
