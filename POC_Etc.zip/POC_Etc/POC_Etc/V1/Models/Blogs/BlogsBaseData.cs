﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    //only common fields
    public class BlogsBaseData
    {
        [JsonProperty(PropertyName = "UrlAddress", Order = 2)]
        public string Url { get; set; }
    }
}
