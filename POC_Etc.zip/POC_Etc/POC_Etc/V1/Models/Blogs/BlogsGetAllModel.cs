﻿using Newtonsoft.Json;
using POC_Etc.API.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public class BlogsGetAllModel : BlogsBaseData, ILinks
    {
        [JsonProperty(PropertyName = "id", Order = 0)]
        public int BlogsId { get; set; }

        /// <inheritdoc/>
        [JsonProperty(PropertyName = "links", Order = 998)]
        public IList<Link> Links { get; set; } = new List<Link>();
    }
}
