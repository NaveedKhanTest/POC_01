﻿using Newtonsoft.Json;
using POC_Etc.API.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{

    /// <summary>
    /// Return full set
    /// </summary>
    public class BlogsGetModel : BlogsBaseData, ILinks
    {
        [JsonProperty(PropertyName = "id", Order = 1)]
        public int BlogsId { get; set; }

        public bool? IsDeleted { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        /// <inheritdoc/>
        [JsonProperty(PropertyName = "links", Order = 998)]
        public IList<Link> Links { get; set; } = new List<Link>();
    }
}
