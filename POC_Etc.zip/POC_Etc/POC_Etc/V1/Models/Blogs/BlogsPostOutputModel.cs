﻿using Newtonsoft.Json;
using POC_Etc.API.Core.Models.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public class BlogsPostOutputModel : ModelWithMessagesAndLinks
    {
        [JsonProperty(PropertyName = "id", Order = 1)]
        public int BlogsId { get; set; }

    }
}
