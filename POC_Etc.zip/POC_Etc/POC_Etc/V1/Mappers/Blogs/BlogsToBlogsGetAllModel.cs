﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POC.Data.Models;

namespace POC_Etc.API.V1.Models.Blogs
//namespace POC_Etc.API.V1.Mappers.Blogs
{
    public static class BlogsToBlogsGetAllModel
    {
        public static BlogsGetAllModel AsBlogsGetAllModel(this POC.Data.Models.Blogs source)
        {
            source = source ?? throw new ArgumentNullException(nameof(source));

            return new BlogsGetAllModel()
            {
                BlogsId = source.BlogsId,
                Url = source.Url,
            };
        }

        /// <summary>
        /// AsBlogsGetModel
        /// </summary>
        /// <param name="source">source</param>
        /// <returns>list BlogsGetAllModel</returns>
        public static List<BlogsGetAllModel> AsBlogsGetAllModel(this IEnumerable<POC.Data.Models.Blogs> source)
        {
            var result = new List<BlogsGetAllModel>();

            foreach (var item in source)
            {
                result.Add(item.AsBlogsGetAllModel());
            }

            return result;
        }


    }
}
