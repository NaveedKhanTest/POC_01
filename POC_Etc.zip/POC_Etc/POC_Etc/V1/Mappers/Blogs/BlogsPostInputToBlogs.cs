﻿using POC_Etc.API.V1.Models.Blogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC_Etc.API.V1.Models.Blogs
{
    public static class BlogsPostInputToBlogs
    {
        public static POC.Data.Models.Blogs AsBlogs(this BlogsPostInput source)
        {
            source = source ?? throw new ArgumentNullException(nameof(source));

            return new POC.Data.Models.Blogs()
            {
                Url = source.Url,
                IsDeleted = source.IsDeleted,
                CreatedBy = "Some user",
                CreateDateTime = DateTime.UtcNow,
            };
        }
    }
}
