﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using POC.Data.Models;

namespace POC_Etc.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            var db = new BloggingDbContext();

            Random rnd = new Random();
            int randomNumber = rnd.Next(1000, 9999);  // creates a number between 1000 and 9999

            db.Blogs.Add(
                new Blogs()
                {
                    Url = $"SomeBlog{randomNumber}.com" ,
                    CreatedBy = "Integration Test",
                    IsDeleted = false,
                });

            db.SaveChanges();
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
            //var db = new POC_DbContext();
            //db.Students.Add(new Students()
            //{
            //    FullName = "Some Name 1",
            //    CreateDateTime = DateTime.Now,
            //    CreatedBy = "Test User1",
            //});
            //db.SaveChanges();

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
