
-- drop DATABASE [BloggingDb];

CREATE DATABASE [BloggingDb];
GO

USE [BloggingDb];
GO

CREATE TABLE [Blogs] (
    [BlogsId] int NOT NULL IDENTITY,
    [Url] nvarchar(max) NOT NULL,
	[IsDeleted] [bit] NULL,
	[CreateDateTime] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedDateTime] [datetime] NULL,
    CONSTRAINT [PK_Blogs] PRIMARY KEY ([BlogsId])
);
GO

ALTER TABLE [dbo].[Blogs] ADD  CONSTRAINT [DF_Blogs_CreateDateTime]  DEFAULT (getdate()) FOR [CreateDateTime]
GO

CREATE TABLE [Authors] (
    [AuthorsId] int NOT NULL IDENTITY,    
    [AuthorsName] [varchar](100) NULL,
	[IsDeleted] [bit] NULL,
	[CreateDateTime] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedDateTime] [datetime] NULL,
    CONSTRAINT [PK_Authors] PRIMARY KEY ([AuthorsId]),
);
GO

ALTER TABLE [dbo].[Authors] ADD  CONSTRAINT [DF_Authors_CreateDateTime]  DEFAULT (getdate()) FOR [CreateDateTime]
GO


CREATE TABLE [Posts] (
    [PostsId] int NOT NULL IDENTITY,
    [BlogsId] int NOT NULL,
    [AuthorsId] int NOT NULL,
    [Content] nvarchar(max),
    [Title] nvarchar(max),
	[IsDeleted] [bit] NULL,
	[CreateDateTime] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedDateTime] [datetime] NULL,
    CONSTRAINT [PK_Posts] PRIMARY KEY ([PostsId]),
    CONSTRAINT [FK_Posts_Blogs_BlogsId] FOREIGN KEY ([BlogsId]) REFERENCES [Blogs] ([BlogsId]) ON DELETE CASCADE,
    CONSTRAINT [FK_Posts_Authors_AuthorsId] FOREIGN KEY ([AuthorsId]) REFERENCES [Authors] ([AuthorsId]) ON DELETE CASCADE
);
GO

ALTER TABLE [dbo].[Posts] ADD  CONSTRAINT [DF_Posts_CreateDateTime]  DEFAULT (getdate()) FOR [CreateDateTime]
GO


INSERT INTO [Blogs] (Url, [IsDeleted]) VALUES
('http://blogs.msdn.com/dotnet', 0),
('http://blogs.msdn.com/webdev', 0),
('http://blogs.msdn.com/visualstudio', 1)
GO


INSERT INTO [Authors] ( [AuthorsName], [IsDeleted]) VALUES
( 'Author1',  0),
( 'Author - 2nd',  0),
( 'Author - 3rd',  1)
GO


INSERT INTO [Posts] ([BlogsId], [AuthorsId], [Content], [Title], [IsDeleted]) VALUES
(1, 1, 'Some Content1', 'Title 01', 0),
(2, 2, 'Some Content 2nd', 'Title 02', 1)
GO

