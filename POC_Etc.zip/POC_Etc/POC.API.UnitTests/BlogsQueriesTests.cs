using Microsoft.EntityFrameworkCore;
using POC.Data.Models;
using System;
using Xunit;

using System.Collections.Generic;

using Moq;
using POC.Domain.Repositories;
using POC_Etc.API.V1.Queries;
using System.Linq;

namespace POC.API.UnitTests
{
    public class BlogsQueriesTests
    {
        /// <summary>
        /// we need to use in memory Db due to 
        ///  Func<IQueryable<Blogs>
        /// </summary>
        [Fact]
        public void GetBlogsByIdBy_InMemoryDb()
        {
            var blogInput = new Blogs()
            {
                BlogsId = 5,
                Url = "some123.com",
                IsDeleted = false,
                CreateDateTime = DateTime.UtcNow,
                CreatedBy = "Unit Test"
            };

            // you need to add Microsoft.EntityFrameworkCore.InMemory package
            //to use UseInMemoryDatabase() extension method with DbContextOptionsBuilder:

            // use in-memory database for DBContext.
            var options = new DbContextOptionsBuilder<BloggingDbContext>()
                .UseInMemoryDatabase(databaseName: nameof(GetBlogsByIdBy_InMemoryDb))
                .Options;

            //var options = new DbContextOptionsBuilder<BloggingDbContext>().UseInMemoryDatabase(databaseName: "dbName").Options;

            //using (var context = new BloggingDbContext(options))
            //{
            //    // add service here
            //}

            using (var dbContext = new BloggingDbContext(options))
            {
                dbContext.Blogs.Add(blogInput);
                dbContext.SaveChanges();

                //var mockBlogsQueries = new Mock<IBlogsQueries>(dbContext)
                //{
                //    CallBase = true
                //};

                var mockBlogsRepository = new Mock<BlogsRepository>(dbContext)
                {
                    CallBase = true
                };

                IBlogsQueries blogsQueries = new BlogsQueries(mockBlogsRepository.Object);

                var result = blogsQueries.GetBlogsById(blogInput.BlogsId).GetAwaiter().GetResult();

                Assert.NotNull(result);

                Assert.Equal(result.BlogsId, blogInput.BlogsId);
                Assert.True(result.Url == blogInput.Url, "Url didn't match");
                Assert.True(result.CreatedBy == blogInput.CreatedBy, "CreatedBy didn't match");
            }

        }



        [Fact]
        public void GetAllBlogs()
        {
            var blogInput1 = new Blogs()
            {
                BlogsId = 5,
                Url = "some123.com",
                IsDeleted = false,
                CreateDateTime = DateTime.UtcNow,
                CreatedBy = "Unit Test"
            };

            var blogsList = new List<Blogs>();
            blogsList.Add(blogInput1);

            var mockBlogsRepository = new Mock<IBlogsRepository>();


            mockBlogsRepository.Setup(x => x.GetAllBlogss()).ReturnsAsync(blogsList);

            IBlogsQueries blogsQueries = new BlogsQueries(mockBlogsRepository.Object);

            var result = blogsQueries.GetAllBlogs().GetAwaiter().GetResult();

            Assert.NotNull(result);

            for (int i = 0; i < result.Count; i++)
            {
                Assert.Equal(result[i].BlogsId, blogsList[i].BlogsId);
                Assert.True(result[i].Url == blogsList[i].Url, $"Url didn't match at index {i}");
            }

        }
    }
}
