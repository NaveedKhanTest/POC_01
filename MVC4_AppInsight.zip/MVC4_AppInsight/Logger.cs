﻿using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace MVC4_AppInsight
{
    /// <summary>
    /// https://www.codeproject.com/Tips/1044948/Logging-with-ApplicationInsights
    /// </summary>
    public class Logger : ILogger
    {
        private TelemetryClient _appInsightsClient;

        public Logger()
        {
            _appInsightsClient = new TelemetryClient();
            var key = ConfigurationManager.AppSettings["InstrumentationKey"];
            _appInsightsClient.InstrumentationKey = ConfigurationManager.AppSettings["InstrumentationKey"];
            //_appInsightsClient.InstrumentationKey = ConfigManager.Insights_Key;
        }

        public void Info(string message)
        {
            var properties = new Dictionary<string, string> { { "message", message } };
            _appInsightsClient.TrackEvent("Info", properties);
            //_appInsightsClient.TrackRequest
        }

        public void Warn(string message)
        {
            var properties = new Dictionary<string, string> { { "message", message } };
            _appInsightsClient.TrackEvent("Warn", properties);
        }

        public void Debug(string message)
        {
            var properties = new Dictionary<string, string> { { "message", message } };
            _appInsightsClient.TrackEvent("Debug", properties);
        }

        public void Error(string message, Exception ex)
        {
            var properties = new Dictionary<string, string> { { "message", message } };
            _appInsightsClient.TrackException(ex, properties);
        }

        public void Error(string message)
        {
            var properties = new Dictionary<string, string> { { "message", message } };
            Exception ex = new Exception(message);
            _appInsightsClient.TrackException(ex, properties);
        }

        public void Error(Exception ex)
        {
            _appInsightsClient.TrackException(ex);
        }
    }
}